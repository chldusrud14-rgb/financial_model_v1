(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var el = function (t, c, h) { var e = document.createElement(t); if (c) e.className = c; if (h !== undefined) e.innerHTML = h; return e; };
  var M = window.SolarModel2, X = window.SolarXlsx2;

  // 착공시점+공사기간 -> 준공시점(COD) 표시용 계산 — engine2.js의
  // ym()/addM()과 같은 방식(월 단위, "착공월+공사기간=준공 다음달"이라
  // 마지막 달은 -1). 순수 화면 표시용이라 엔진 계산에는 관여하지 않는다.
  function updateCodDisplay() {
    var disp = $('[data-display="codDisplay"]');
    if (!disp) return;
    var startEl = $('[data-k="constructionStart"]'), monthsEl = $('[data-k="constructionMonths"]');
    if (!startEl || !monthsEl) return;
    var m = /^(\d{4})-(\d{1,2})$/.exec(startEl.value || '');
    var months = Number(monthsEl.value);
    if (!m || !months) { disp.textContent = '—'; return; }
    var y = Number(m[1]), mo = Number(m[2]);
    var t = y * 12 + (mo - 1) + months - 1; // 준공월(착공 포함 공사기간 마지막 달)
    var cy = Math.floor(t / 12), cm = (t % 12) + 1;
    disp.textContent = cy + '-' + (cm < 10 ? '0' + cm : cm);
  }

  /* ---------- 기본 입력 필드 ----------
     essential: 항상 보이는 핵심 가정. 나머지는 그룹별로 묶어서
     "상세 가정" 접힘 영역에 넣는다 — 26개를 한 화면에 쭉 나열하지 않는다. */
  var CORE = [
    { k: 'projectName', label: '사업명', type: 'text', def: '태양광 발전사업', essential: true },
    { k: 'capacityMW', label: '설비용량', type: 'number', def: 99.998, unit: 'MW', essential: true },
    // 발전량 산식 입력은 발전원에 따라 하나만 쓴다(plantType 참조).
    //  태양광 → dailyHours,  풍력 → capacityFactor × availability
    { k: 'dailyHours', label: '일일 발전시간(환산)', type: 'number', def: 3.77, unit: 'h/day', essential: true,
      plant: 'solar',
      hint: '하루 24시간 중 정격출력으로 발전한 것으로 환산한 시간. 이용률(%) = 이 값÷24. 보통 3.3~3.9' },
    { k: 'capacityFactorPct', label: '이용률(Capacity Factor)', type: 'number', def: 30.5, unit: '%', essential: true,
      plant: 'wind',
      hint: '정격출력 대비 실제 발전량 비율. 육상풍력 20~30%, 해상풍력 30~40% 수준입니다.' },
    { k: 'availability', label: '가동률(Availability)', type: 'number', def: 97, unit: '%', essential: true,
      plant: 'wind',
      hint: '정비·고장 등으로 못 도는 시간을 뺀 설비 가동 가능 비율. 발전량에 이용률과 곱해서 반영됩니다.' },
    { k: 'tariff', label: 'PPA 또는 SMP+REC 판매단가', type: 'number', def: 154.8, unit: '원/kWh', essential: true,
      hint: 'PPA·SMP+REC 등 여러 단가를 물량가중평균한 값' },
    { k: 'capexEok', label: '총사업비(건설이자 제외)', type: 'number', def: 1410.69, unit: '억원', essential: true,
      toggle: { id: 'capexDetailToggle', label: '항목별 입력' },
      hint: 'EPC·인허가·개발비 등 순수 공사비 합계 — 건설이자(IDC)는 여기 포함 안 함, 자동 계산됨. 항목별 금액을 모르면 체크하지 말고 합계만 입력(빠른 사업성 검토용) — 체크하면 아래 항목 표가 나타나고 이 필드는 항목 합계로 자동 계산됩니다.' },
    { k: 'opexEok', label: '운영비(1년차 기준)', type: 'number', def: 49.8, unit: '억원/yr', essential: true,
      toggle: { id: 'opexDetailToggle', label: '항목별 입력' },
      hint: '항목별 금액을 모르면 체크하지 말고 합계만 입력하세요. 체크하면 항목별 상승률·선순위/후순위까지 반영돼서 계산 정확도가 올라갑니다(총액 근사 대신 항목별 계산 사용).' },
    { k: 'equityEok', label: '자본금(Equity)', type: 'number', def: 150, unit: '억원', essential: true,
      hint: '전체 출자자의 출자금 합계(Equity 총액)입니다 — 개별 출자자 지분율은 아래 "사업자 구성"에서 나눕니다.' },
    { k: 'equityRatioPct', label: '자기자본비율(선택)', type: 'number', def: '', unit: '%', essential: true, uiOnly: true,
      hint: '총조달 소요액(= 총사업비 + DSRA 적립 + 건설이자) 대비 비율입니다 — 금융권이 보는 기준. 입력하면 자본금과 부채를 이 비율로 자동 산정합니다(비워두면 위 자본금 절대값을 그대로 씀). 자본금을 직접 고치면 이 값도 같이 갱신됩니다.' },

    { k: 'degradation', label: '연간 출력저하(Degradation)', type: 'number', def: 0.5, unit: '%/yr', group: '발전소 특성',
      hint: '매년 정액으로 발전량이 이만큼씩 줄어든다고 가정 (복리 아님)' },
    { k: 'auxRate', label: '소내 소비율', type: 'number', def: 0, unit: '%', group: '발전소 특성',
      hint: '발전한 전력 중 설비 자체가 쓰는 비율' },
    { k: 'constructionStart', label: '착공시점', type: 'text', def: '2024-06', unit: 'YYYY-MM', group: '발전소 특성' },
    { k: 'constructionMonths', label: '공사기간', type: 'number', def: 16, unit: 'Month', group: '발전소 특성' },
    { k: 'codDisplay', label: '준공시점(COD, 자동계산)', type: 'display', group: '발전소 특성',
      hint: '착공시점+공사기간으로 자동 계산됩니다 — 직접 입력하는 칸이 아닙니다.' },
    { k: 'operationYears', label: '운영기간', type: 'number', def: 20, unit: 'Year', group: '발전소 특성' },

    { k: 'dsraEok', label: '최초 DSRA', type: 'number', def: 50, unit: '억원', group: '재원조달·감가상각',
      hint: '원리금 상환이 막힐 때를 대비해 준공 시점에 따로 쌓아두는 예비재원입니다. ' +
            '기본값은 설비용량 × 0.5억/MW(당진 FS 50억 ÷ 100MW)로 자동 계산됩니다. ' +
            '대주단은 보통 "향후 6개월분 원리금"을 요구하므로, 차입 규모·금리가 정해지면 그 금액을 직접 입력하세요.' },
    { k: 'depRatio', label: '감가상각 대상비율', type: 'number', def: 95, unit: '%', group: '재원조달·감가상각',
      hint: '총투자비 중 감가상각 대상 자산의 비율(토지 등 제외분 빼고)' },
    { k: 'depYears', label: '감가상각 내용연수', type: 'number', def: 20, unit: 'Year', group: '재원조달·감가상각' },

    { k: 'tariffEscal', label: '판매단가 상승률', type: 'number', def: 0, unit: '%/yr', group: '매출' },
    { k: 'rpsShare', label: 'RPS(SMP+REC) 비중', type: 'number', def: 0, unit: '%', group: '매출',
      hint: '설비용량 중 SMP+REC(RPS)로 정산받는 비중. 나머지는 PPA(위 "판매단가")로 계산됩니다. 0이면 기존과 동일하게 전량 PPA로 계산됩니다.' },
    { k: 'smpPrice', label: 'SMP 단가', type: 'number', def: 135, unit: '원/kWh', group: '매출',
      hint: 'RPS 비중이 0보다 클 때만 사용됩니다.' },
    { k: 'recPrice', label: 'REC 단가', type: 'number', def: 70, unit: '원/kWh', group: '매출',
      hint: 'RPS 비중이 0보다 클 때만 사용됩니다.' },
    { k: 'recWeight', label: 'REC 가중치', type: 'number', def: 1, unit: '배', group: '매출',
      hint: '설비용량 구간별 REC 가중치. RPS 비중이 0(전량 PPA)이면 의미가 없어 자동으로 1로 고정되고 입력이 잠깁니다.' },
    { k: 'arLagPPA', label: 'PPA 대금 회수 시차', type: 'number', def: 1, unit: '개월', group: '매출',
      hint: '전기를 판 달과 대금이 실제로 들어오는 달의 차이. 검침·청구·지급 주기 때문에 통상 1개월입니다(당진 FS도 PPA1·PPA2 각각 1개월로 가정). 0으로 두면 시차 없이 즉시 회수로 계산합니다.' },
    { k: 'arLagSMP', label: 'SMP 대금 회수 시차', type: 'number', def: 1, unit: '개월', group: '매출',
      hint: '전력거래소 정산 주기. RPS 비중이 0보다 클 때만 사용됩니다.' },
    { k: 'arLagREC', label: 'REC 대금 회수 시차', type: 'number', def: 2, unit: '개월', group: '매출',
      hint: 'REC는 발급·거래 절차가 더 붙어 SMP보다 통상 한 달 더 걸립니다. RPS 비중이 0보다 클 때만 사용됩니다.' },

    { k: 'opexEscal', label: '운영비 상승률', type: 'number', def: 0.7, unit: '%/yr', group: '운영비' },
    { k: 'decomEok', label: '철거·복구비(만기 시점)', type: 'number', def: 20, unit: '억원', group: '운영비',
      hint: '운영이 끝난 뒤 설비를 철거하고 부지를 원상복구하는 비용입니다(만기에 지급, 운영기간 동안 충당금으로 나눠 비용 처리). ' +
            '기본값은 설비용량 × 0.2억/MW(당진 FS 20억 ÷ 100MW)로 자동 계산됩니다. 견적이 있으면 직접 입력하세요.' },

    { k: 'lossRate', label: '이월결손금 공제한도', type: 'number', def: 80, unit: '%', group: '세무',
      hint: '그 해 과세소득 중 이월결손금으로 상계 가능한 비율' },
    { k: 'taxFlat', label: '단일 법인세율', type: 'number', def: 21, unit: '%', group: '세무',
      toggle: { id: 'taxFlatToggle', label: '단일세율 사용' },
      hint: '기본은 한국 법인세 누진 브래킷(2억 9% / 200억 19% / 3000억 21% / 초과 24%). ' +
            '위 "단일세율 사용"을 켜면 이 칸의 세율 하나로만 계산합니다.' },

    { k: 'dsraMonths', label: 'DSRA 적립기준', type: 'number', def: 6, unit: 'Month', group: '현금관리·배당',
      hint: '차기 몇 개월분 원리금을 항상 예비로 쌓아둘지' },
    { k: 'minCash', label: '배당 후 최소보유현금', type: 'number', def: 10, unit: '억원', group: '현금관리·배당',
      hint: '배당을 하고 난 뒤에도 회사에 남겨둘 최소 현금입니다. ' +
            '기본값은 설비용량 × 0.1억/MW(당진 FS 10억 ÷ 100MW)로 자동 계산됩니다.' },
    { k: 'divDSCR', label: '배당제한 — 단순DSCR', type: 'number', def: 1.1, unit: 'x', group: '현금관리·배당',
      hint: '이 값 미만이면 그 분기 원리금 상환여력이 부족하다고 보고 배당을 막음' },
    { k: 'divCumDSCR', label: '배당제한 — 누적DSCR', type: 'number', def: 1.15, unit: 'x', group: '현금관리·배당' },
    { k: 'divStartYear', label: '배당개시 연차', type: 'number', def: 2, unit: 'Year', group: '현금관리·배당',
      hint: '"당진 FS 불러오기"를 안 썼을 때만 적용되는 간이 기준(실측 배당 로직 미사용 시 폴백)' },

    { k: 'discount', label: '할인율(NPV 계산용)', type: 'number', def: 5.5, unit: '%', group: '평가' }
  ];

  // 총사업비/운영비 항목별 상세 입력 — 신속한 사업성 검토(합계만 입력)와
  // 정밀 검토(항목별 입력) 둘 다 지원. 기본은 합계만 쓰는 간단 모드고,
  // 체크박스로 항목별 입력 모드를 켤 수 있다. 항목명은 원본 당진 FS의
  // 총사업비/운영비 세부내역 구성을 그대로 템플릿으로 씀(건설이자·DSRA는
  // 별도 필드로 이미 있어서 제외).
  var DEFAULT_CAPEX_ITEMS = ['EPC', '감리비', '공사보험료', '토지임대료(선납)', '토지임대료(분납)',
    '사업개발비', '민원처리비', '사업성자문비', '법인운영비', '기타예비비', '신주발행비용', '금융부대비용'];
  // 지급순위 기본값은 전부 선순위(원본 당진 실측치는 항목별로 다르지만,
  // 화면 템플릿 기본값은 단순하게 전부 선순위로 시작 — 필요하면 사용자가
  // 개별 항목만 후순위로 바꾸면 됨).
  var DEFAULT_OPEX_ITEMS = [
    { name: '부지임대료', escal: 0, senior: true },
    { name: 'O&M', escal: 1.5, senior: true },
    { name: '보험료', escal: 0, senior: true },
    { name: '환경모니터링비용', escal: 0, senior: true },
    { name: '소내전력비', escal: 2, senior: true },
    { name: '인건비', escal: 2, senior: true },
    { name: '법인운영비', escal: 2, senior: true },
    { name: '주민보상비', escal: 0, senior: true },
    { name: '도로점용료', escal: 0, senior: true },
    { name: '예비비', escal: 0, senior: true },
    { name: '전력거래수수료', escal: 0, senior: true },
    { name: '관리운영비 성과보수', escal: 0, senior: true }
  ];
  // 풍력 기본 항목 — KPMG 흑백풍력 모델(Control!143~155, Opex!13~22) 구성 반영.
  var WIND_CAPEX_ITEMS = ['풍력발전기(WTG)', '하부구조물', '발전기 운송·설치', '육상케이블/변전소',
    '해저케이블', '변전소·사무소 부지', '민원보상비·전력망', '사업개발비(DEVEX)',
    '공사보험료', '건설기간 인건비·운영비', '감리비', '공사 예비비'];
  var WIND_OPEX_ITEMS = [
    { name: 'LTSA(WTG)', escal: 1.5, senior: true },
    { name: 'LTSA(BOP)', escal: 1.5, senior: true },
    { name: '인건비', escal: 1.5, senior: true },
    { name: '보험료', escal: 1.5, senior: true },
    { name: '부지임차료', escal: 1.5, senior: true },
    { name: '전력거래수수료', escal: 0, senior: true },
    { name: 'REC 발급수수료', escal: 0, senior: true },
    { name: 'REC 거래수수료', escal: 0, senior: true },
    { name: '기타경비', escal: 1.5, senior: true },
    { name: '기타예비비', escal: 0, senior: true }
  ];
  function defaultCapexItemsFor(pt) { return pt === 'wind' ? WIND_CAPEX_ITEMS : DEFAULT_CAPEX_ITEMS; }
  function defaultOpexItemsFor(pt) { return pt === 'wind' ? WIND_OPEX_ITEMS : DEFAULT_OPEX_ITEMS; }

  var capexDetailOn = false, opexDetailOn = false;
  // 단일세율 토글 — 꺼져 있으면 누진 브래킷(기본), 켜면 taxFlat 한 값만 쓴다.
  var taxFlatOn = false;
  // 현재 항목 목록이 어느 발전원 기준인지 — 금액이 입력돼 있으면 발전원을 바꿔도
  // 목록을 함부로 덮어쓰지 않기 때문에, 어긋난 상태를 사용자에게 알려줘야 한다.
  var capexItemsPlant = 'solar', opexItemsPlant = 'solar';
  var CAPEX_ITEMS = DEFAULT_CAPEX_ITEMS.map(function (n) { return { name: n, amountEok: null }; });
  var OPEX_ITEMS = DEFAULT_OPEX_ITEMS.map(function (d) { return { name: d.name, amountEok: null, escal: d.escal, senior: d.senior }; });

  var SHAREHOLDERS = [{ name: '출자자1', stakePct: 100 }];

  // 민감도 분석 시나리오 — 판매단가(원/kWh)/총사업비(억원)/운영비(억원)/
  // 금리(%) 전부 델타가 아니라 절대값. 빈 칸이면 "사업 기본 가정"에 입력한
  // 값을 그대로 쓴다. Base는 위 입력값을 그대로 참조하는 기준행이라
  // "↑" 버튼으로 채울 수 있고, Case들은 사용자가 원하는 값을 직접
  // 입력하는 행이라 버튼이 없다 — 더 필요하면 "+ 시나리오 추가"로 늘린다.
  var SENS_ROWS = [
    { name: 'Base', tariffAbs: null, capexAbs: null, opexAbs: null, rateAbs: null },
    { name: 'Case1', tariffAbs: null, capexAbs: null, opexAbs: null, rateAbs: null },
    { name: 'Case2', tariffAbs: null, capexAbs: null, opexAbs: null, rateAbs: null }
  ];
  var lastSensResults = null;

  var TRANCHES = [
    { key: 'A', name: '선순위A', amountEok: 500, order: 2, rateO: 5.6, graceYears: 2, repayYears: 16 },
    { key: 'B', name: '선순위B', amountEok: 500, order: 2, rateO: 5.5, graceYears: 2, repayYears: 16 },
    { key: 'C', name: '선순위C', amountEok: 350, order: 4, rateO: 5.5, graceYears: 1.25, repayYears: 16 },
    { key: 'D', name: '선순위D', amountEok: 0, order: 3, rateO: 2.25, graceYears: 5, repayYears: 10 },
    { key: 'sub', name: '후순위', amountEok: 0, order: 1, rateO: 5.65, graceYears: 15, repayYears: 2.75 }
  ];

  function fieldEl(d) {
    var wrapf = el('div', 'f' + (d.type === 'text' ? ' full' : ''));
    if (d.toggle) {
      var labelRow = el('div', 'flabel');
      labelRow.appendChild(el('label', null, d.label));
      var tg = document.createElement('label');
      tg.className = 'ftoggle';
      var cb = document.createElement('input');
      cb.type = 'checkbox'; cb.id = d.toggle.id;
      tg.appendChild(cb);
      tg.appendChild(document.createTextNode(' ' + d.toggle.label));
      labelRow.appendChild(tg);
      wrapf.appendChild(labelRow);
    } else {
      wrapf.appendChild(el('label', null, d.label));
    }
    var inw = el('div', 'in2');
    if (d.type === 'display') {
      // 입력칸이 아니라 다른 필드에서 자동 계산되는 값을 보여주기만
      // 하는 필드(예: 준공시점) — mwref와 같은 성격으로 input 대신
      // 회색 이탤릭 텍스트로 렌더링.
      var disp = document.createElement('span');
      disp.className = 'mwref'; disp.style.textAlign = 'left';
      disp.dataset.display = d.k;
      disp.textContent = '—';
      inw.appendChild(disp);
    } else {
      var input = document.createElement('input');
      input.type = d.type === 'text' ? 'text' : 'number';
      input.step = 'any';
      input.value = d.def;
      input.dataset.k = d.k;
      inw.appendChild(input);
      if (d.unit) inw.appendChild(el('span', 'unit', d.unit));
    }
    wrapf.appendChild(inw);
    if (d.hint) wrapf.appendChild(el('div', 'fhint', d.hint));
    return wrapf;
  }

  // 필수 입력 배치 — 자동 2열 순서채움 대신 명시적으로 행을 지정해서
  // "총사업비+운영비", "자본금+자기자본비율"이 나란히 붙게 한다.
  var ESSENTIAL_ROWS = [
    ['projectName'],
    ['capacityMW', 'dailyHours'],           // dailyHours = 태양광 전용
    ['capacityFactorPct', 'availability'],  // 둘 다 풍력 전용
    ['tariff'],
    ['capexEok', 'opexEok'],
    ['equityEok', 'equityRatioPct']
  ];
  function fieldByKey(k) { return CORE.filter(function (d) { return d.k === k; })[0]; }

  /* ---------- 발전원(태양광/풍력) ----------
     계산 엔진의 대부분(자금조달·IDC·부채상환·DSCR·법인세·배당·IRR)은
     발전원과 무관해서 그대로 공유하고, 실제로 달라지는 것만 전환한다:
       1) 발전량 산식  — 태양광 일조시간 / 풍력 이용률×가동률
       2) 총사업비 항목 기본 목록
       3) 운영비 항목 기본 목록
     화면/엔진을 따로 만들지 않는 이유는, 나누면 공통 로직을 고칠 때마다
     양쪽을 똑같이 고쳐야 해서 반드시 어긋나기 때문. */
  var plantType = 'solar';
  function isFieldVisible(d) { return !d.plant || d.plant === plantType; }

  /* 발전원 비교표 — 두 모델이 "무엇이 다르고 무엇이 같은지"를 한눈에.
     선택된 발전원 열을 강조해서, 지금 어느 기준으로 계산되는지 바로 보이게 한다.
     항목 목록은 실제 기본 배열에서 직접 뽑는다 — 표와 실제 항목이 어긋나지 않도록. */
  var PLANT_CMP_TOP = [
    ['발전량 산식',
     '설비용량 × <b>일일 발전시간</b> × 365일',
     '설비용량 × 8,760h × <b>이용률</b> × <b>가동률</b>'],
    ['전용 입력칸',
     '일일 발전시간 (h/일)',
     '이용률 (%) · 가동률 (%)']
  ];
  var PLANT_LABEL = { solar: '태양광', wind: '풍력' };
  var CMP_HEAD_N = 3;   // 접힌 상태에서 보여줄 항목 수

  function cmpList(names, key) {
    var esc = names.map(function (n) { return n.replace(/&/g, '&amp;').replace(/</g, '&lt;'); });
    if (esc.length <= CMP_HEAD_N) return esc.join(' · ');
    return '<span class="cmpHead">' + esc.slice(0, CMP_HEAD_N).join(' · ') + '</span>' +
      '<span class="cmpRest" data-cmp-rest="' + key + '" hidden> · ' + esc.slice(CMP_HEAD_N).join(' · ') + '</span>' +
      ' <button type="button" class="cmpMore" data-cmp-more="' + key + '">더보기</button>';
  }

  function plantCmpHtml(pt) {
    var rows = PLANT_CMP_TOP.concat([
      ['총사업비 기본항목',
       cmpList(DEFAULT_CAPEX_ITEMS, 'cs'),
       cmpList(WIND_CAPEX_ITEMS, 'cw')],
      ['운영비 기본항목',
       cmpList(DEFAULT_OPEX_ITEMS.map(function (d) { return d.name; }), 'os'),
       cmpList(WIND_OPEX_ITEMS.map(function (d) { return d.name; }), 'ow')]
    ]);
    var h = '<table class="plantCmp"><tr><th></th>' +
      '<th class="' + (pt === 'solar' ? 'col-on' : '') + '">태양광</th>' +
      '<th class="' + (pt === 'wind' ? 'col-on' : '') + '">풍력</th></tr>';
    rows.forEach(function (r) {
      h += '<tr><td>' + r[0] + '</td>' +
        '<td class="' + (pt === 'solar' ? 'col-on' : '') + '">' + r[1] + '</td>' +
        '<td class="' + (pt === 'wind' ? 'col-on' : '') + '">' + r[2] + '</td></tr>';
    });
    h += '<tr class="same"><td>공통 (동일)</td><td colspan="2">' +
      '자금조달 · 인출순서 · 건설이자(IDC) · 부채상환(방식 1/2/3) · 판매단가 트랙 · ' +
      '대금회수 시차 · 법인세 · 배당 · DSCR · IRR — <b>계산 로직은 두 발전원이 완전히 동일</b></td></tr>';
    return h + '</table>';
  }

  // 표는 발전원을 바꿀 때마다 다시 그려지므로, 펼치기 버튼은 위임으로 한 번만 건다.
  function bindPlantCmp() {
    var box = $('#plantHint'); if (!box) return;
    box.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.cmpMore') : null;
      if (!b) return;
      var rest = box.querySelector('[data-cmp-rest="' + b.getAttribute('data-cmp-more') + '"]');
      if (!rest) return;
      var open = rest.hasAttribute('hidden');
      if (open) { rest.removeAttribute('hidden'); b.textContent = '접기'; }
      else { rest.setAttribute('hidden', ''); b.textContent = '더보기'; }
    });
  }
  // 발전원 표준 항목으로 목록을 교체한다(금액은 비워짐). 사용자가 금액을 이미
  // 넣어둔 경우엔 자동으로 부르지 않고, 아래 안내의 버튼을 눌렀을 때만 실행된다.
  function applyPlantCapexItems(pt) {
    CAPEX_ITEMS = defaultCapexItemsFor(pt).map(function (n) { return { name: n, amountEok: null }; });
    capexItemsPlant = pt;
    // 항목별 입력이 꺼져 있으면 목록만 바꾸고 표는 그리지 않는다 — 예전엔 발전원을
    // 바꾸면 꺼진 상태에서도 빈 항목 표가 화면(과 인쇄)에 나타났다.
    if (capexDetailOn) buildCapexItemGrid();
  }
  function applyPlantOpexItems(pt) {
    OPEX_ITEMS = defaultOpexItemsFor(pt).map(function (d) { return { name: d.name, amountEok: null, escal: d.escal, senior: d.senior }; });
    opexItemsPlant = pt;
    if (opexDetailOn) buildOpexItemGrid();
  }

  // 지금 화면의 항목 목록이 선택한 발전원과 다르면(금액이 있어서 안 바꾼 경우)
  // 그 사실을 알려주고 원할 때 교체할 수 있는 버튼을 붙인다.
  function plantMismatchNote(box, itemsPlant, onApply) {
    if (itemsPlant === plantType) return;
    var d = el('div', 'plantWarn');
    d.innerHTML = '지금 목록은 <b>' + PLANT_LABEL[itemsPlant] + '</b> 표준 항목입니다. ' +
      '금액이 입력돼 있어 자동으로 바꾸지 않았습니다.';
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'btn ghost';
    b.textContent = PLANT_LABEL[plantType] + ' 표준 항목으로 교체';
    b.addEventListener('click', function () {
      if (!w_confirm(PLANT_LABEL[plantType] + ' 표준 항목으로 교체합니다. 입력한 금액은 지워집니다. 계속할까요?')) return;
      onApply(plantType);
    });
    d.appendChild(b);
    box.appendChild(d);
  }
  function w_confirm(msg) { try { return window.confirm(msg); } catch (e) { return true; } }

  function setPlantType(pt) {
    if (pt === plantType) return;
    plantType = pt;
    // 1) 필드/채움칸 표시 전환
    document.querySelectorAll('[data-plant]').forEach(function (e) {
      e.style.display = (e.getAttribute('data-plant') === pt) ? '' : 'none';
    });
    // 2) 버튼 상태
    document.querySelectorAll('[data-plant-btn]').forEach(function (b) {
      b.classList.toggle('on', b.getAttribute('data-plant-btn') === pt);
    });
    var hint = $('#plantHint'); if (hint) hint.innerHTML = plantCmpHtml(pt);
    // 3) 항목 기본 목록 교체 — 사용자가 입력한 금액이 있으면 덮어쓰지 않는다
    //    (발전원을 잘못 눌렀다가 되돌릴 때 입력이 날아가면 안 되므로).
    if (capexDetailOn) readCapexItems();
    if (opexDetailOn) readOpexItemsDetailed();
    var capexTouched = CAPEX_ITEMS.some(function (it) { return it.amountEok != null && it.amountEok !== ''; });
    var opexTouched = OPEX_ITEMS.some(function (it) { return it.amountEok != null && it.amountEok !== ''; });
    if (!capexTouched) applyPlantCapexItems(pt); else if (capexDetailOn) buildCapexItemGrid();
    if (!opexTouched) applyPlantOpexItems(pt); else if (opexDetailOn) buildOpexItemGrid();
    // 4) 사업명 기본값도 발전원에 맞춰 바꿔준다(사용자가 안 고쳤을 때만)
    var pn = $('[data-k="projectName"]');
    if (pn && (pn.value === '태양광 발전사업' || pn.value === '풍력 발전사업')) {
      pn.value = (pt === 'wind') ? '풍력 발전사업' : '태양광 발전사업';
    }
    // 발전원을 바꾸면 계산 전제가 달라지므로 프리셋(당진 실측치)은 해제한다.
    if (usingPreset) { usingPreset = false; dropUnsupportedMethod3(); }
    toast(pt === 'wind' ? '풍력 기준으로 전환했습니다 — 발전량은 이용률×가동률로 계산됩니다'
                        : '태양광 기준으로 전환했습니다 — 발전량은 일일 발전시간으로 계산됩니다');
  }

  function buildCore() {
    var wrap = $('#core');
    var essential = el('div', 'grid');
    ESSENTIAL_ROWS.forEach(function (row) {
      // 발전원마다 보이는 필드가 달라 행이 쓰는 칸 수도 달라진다 —
      // 두 경우를 각각 세어서 필요한 쪽에만 채움용 빈 칸을 넣는다.
      var colsSolar = 0, colsWind = 0;
      row.forEach(function (k) {
        var d = fieldByKey(k);
        if (!d) return;
        var w = d.type === 'text' ? 2 : 1; // text 필드는 .full로 2칸 다 씀
        if (!d.plant || d.plant === 'solar') colsSolar += w;
        if (!d.plant || d.plant === 'wind') colsWind += w;
        var fe = fieldEl(d);
        // 발전원 전환 시 보였다/숨겼다 해야 하므로 표시를 남겨둔다.
        if (d.plant) { fe.setAttribute('data-plant', d.plant); if (!isFieldVisible(d)) fe.style.display = 'none'; }
        essential.appendChild(fe);
      });
      // 2칸 그리드는 자식을 그냥 순서대로 채우기 때문에, 홀수 칸만 쓴 행은
      // 빈 칸을 하나 더 넣어줘야 다음 행이 새 줄에서 시작한다(안 그러면
      // 다음 행 첫 필드가 이 행의 남은 칸에 끼어들어가 버림).
      if (colsSolar % 2 === 1) {
        var fs = el('div'); fs.setAttribute('data-plant', 'solar');
        if (plantType !== 'solar') fs.style.display = 'none';
        essential.appendChild(fs);
      }
      if (colsWind % 2 === 1) {
        var fw = el('div'); fw.setAttribute('data-plant', 'wind');
        if (plantType !== 'wind') fw.style.display = 'none';
        essential.appendChild(fw);
      }
      // 총사업비/운영비 항목별 입력 표는 해당 필드 바로 아래 줄에 — 위
      // 필드들처럼 반반(1칸씩) 나눠서 나란히 배치한다. display:none으로
      // 숨기면 그리드 흐름에서 아예 빠져버려 다음 필드(자본금)가 옆으로
      // 끌려오는 버그가 있어서, 항상 그리드에 남겨두고 내용만 비워둔다
      // (비어있으면 CSS로 높이 0 처리 — .itemBox:empty 참고).
      if (row.indexOf('capexEok') >= 0) {
        var capexBox = el('div', 'itemBox'); capexBox.id = 'capexItemBox';
        essential.appendChild(capexBox);
      }
      if (row.indexOf('opexEok') >= 0) {
        var opexBox = el('div', 'itemBox'); opexBox.id = 'opexItemBox';
        essential.appendChild(opexBox);
      }
    });
    wrap.appendChild(essential);

    // 그룹별로 묶어서 "상세 가정" 접힘 영역에 — 26개를 한 화면에 쭉 나열하지 않는다.
    var groups = [];
    CORE.filter(function (d) { return !d.essential; }).forEach(function (d) {
      var g = groups.filter(function (x) { return x.name === d.group; })[0];
      if (!g) { g = { name: d.group, items: [] }; groups.push(g); }
      g.items.push(d);
    });
    var det = document.createElement('details');
    det.className = 'more';
    var sum = document.createElement('summary');
    sum.textContent = '상세 가정 (발전소 특성 · 재원조달 · 세무 · 배당 등)';
    det.appendChild(sum);
    var body2 = el('div', 'body2');
    groups.forEach(function (g) {
      var grp = el('div', 'grp');
      grp.appendChild(el('b', null, g.name));
      var gg = el('div', 'grid');
      g.items.forEach(function (d) { gg.appendChild(fieldEl(d)); });
      grp.appendChild(gg);
      body2.appendChild(grp);
    });
    det.appendChild(body2);
    wrap.appendChild(det);
  }

  function capexItemRow(it, idx) {
    var tr = document.createElement('tr');
    var nameTd = document.createElement('td');
    var nameInput = document.createElement('input');
    nameInput.type = 'text'; nameInput.value = it.name; nameInput.dataset.capexIdx = idx; nameInput.dataset.capexF = 'name';
    nameTd.appendChild(nameInput); tr.appendChild(nameTd);
    var amtTd = document.createElement('td');
    var amtInput = document.createElement('input');
    amtInput.type = 'number'; amtInput.step = 'any';
    amtInput.value = it.amountEok === null || it.amountEok === undefined ? '' : it.amountEok;
    amtInput.dataset.capexIdx = idx; amtInput.dataset.capexF = 'amountEok';
    amtTd.appendChild(amtInput); tr.appendChild(amtTd);
    var rmTd = document.createElement('td');
    var rm = document.createElement('button');
    rm.type = 'button'; rm.className = 'rm'; rm.textContent = '×';
    rm.addEventListener('click', function () {
      if (CAPEX_ITEMS.length <= 1) return;
      CAPEX_ITEMS.splice(idx, 1);
      buildCapexItemGrid();
      updateCapexItemSum();
    });
    rmTd.appendChild(rm); tr.appendChild(rmTd);
    return tr;
  }

  function buildCapexItemGrid() {
    var box = $('#capexItemBox');
    if (!box) return;
    box.innerHTML = '';
    var t = el('table', 'tr');
    t.innerHTML = '<thead><tr><th>항목</th><th>금액<br>(억원)</th><th></th></tr></thead>';
    var tb = document.createElement('tbody');
    CAPEX_ITEMS.forEach(function (it, idx) { tb.appendChild(capexItemRow(it, idx)); });
    t.appendChild(tb);
    box.appendChild(t);
    var addBtn = document.createElement('button');
    addBtn.type = 'button'; addBtn.className = 'btn ghost'; addBtn.style.marginTop = '8px';
    addBtn.textContent = '+ 항목 추가';
    addBtn.addEventListener('click', function () {
      CAPEX_ITEMS.push({ name: '항목' + (CAPEX_ITEMS.length + 1), amountEok: null });
      buildCapexItemGrid();
    });
    box.appendChild(addBtn);
    var sum = el('div', 'spendsum'); sum.id = 'capexItemSum';
    box.appendChild(sum);
    plantMismatchNote(box, capexItemsPlant, applyPlantCapexItems);
    updateCapexItemSum();
  }

  function readCapexItems() {
    var trs = Array.prototype.slice.call(document.querySelectorAll('#capexItemBox tbody tr'));
    return trs.map(function (tr) {
      var nameEl = tr.querySelector('[data-capex-f="name"]');
      var amtEl = tr.querySelector('[data-capex-f="amountEok"]');
      return { name: nameEl.value, amountEok: amtEl.value === '' ? null : Number(amtEl.value) };
    });
  }

  function updateCapexItemSum() {
    CAPEX_ITEMS = readCapexItems();
    var sum = CAPEX_ITEMS.reduce(function (a, it) { return a + (it.amountEok || 0); }, 0);
    var box = $('#capexItemSum');
    if (box) box.innerHTML = '<span>항목 합계</span><span>' + sum.toFixed(2) + '억원</span>';
    // 항목 금액을 하나도 안 채운 상태에서는 합계(0)로 총액을 덮지 않는다 —
    // 체크박스를 눌러보기만 해도 입력해둔 총사업비가 0이 되고, 거기에
    // 딸린 지출 스케줄까지 0으로 재생성돼 계산이 깨지던 문제.
    if (capexDetailOn && anyAmount(CAPEX_ITEMS)) {
      var capexEl = $('[data-k="capexEok"]');
      // 합계가 지금 총사업비와 같으면 다시 쓰지 않는다. 총사업비 'change' 는
      // 지출 스케줄을 기본값으로 다시 만드는데, 예시(당진)처럼 실측 스케줄이
      // 들어 있는 상태에서 값이 그대로인데도 덮어쓰면 실측 스케줄이 사라진다.
      // 소수 둘째 자리로 자르면 엑셀(항목을 그대로 SUM)과 최대 0.5백만원씩
      // 어긋난다 — 계산에 쓰이는 값이므로 정밀도를 유지한다.
      if (Math.abs((Number(capexEl.value) || 0) - sum) >= 1e-6) {
        // 총사업비가 바뀌면 소요액도 바뀐다 — 자동 산정 상태면 부채를 다시 맞춘다(아래 setTimeout)
        if (debtAutoSized && !suppressDirty) setTimeout(function () { if (debtAutoSized) autoSizeFunding({ silent: true }); }, 0);
        capexEl.value = +sum.toFixed(6);
        capexEl.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
  }

  // box를 display:none으로 숨기면 CSS 그리드 배치에서 그 자리가 통째로
  // 빠져버려서(그리드는 display:none 요소를 아예 없는 것처럼 취급),
  // 바로 다음 필드(자본금)가 옆 칸(운영비 표 자리)으로 끌려 올라오는
  // 버그가 있었다 — 항상 그리드 흐름에는 남겨두고, 안 켰을 때는
  // 내용만 비워서 높이가 0에 가깝게 만드는 방식으로 고친다.
  /* 항목별 입력 토글 — 켜면 합계 필드가 항목 합으로 자동 계산되고 잠긴다.
     그런데 항목 금액을 아직 안 채운 상태에서 켰다 끄면 합계가 0으로
     덮여서 원래 입력해둔 총액이 그대로 날아가는 문제가 있었다.
     (체크박스를 눌러봤다가 되돌리는 건 지극히 정상적인 사용 동작인데
      그때마다 값이 사라지면 안 된다.)
     → 켤 때 직전 총액을 기억해두고, 끌 때 항목에 실제로 채운 금액이
       하나도 없으면 기억해둔 값을 되살린다. 항목을 채웠다면 그건
       사용자가 의도한 값이므로 계산된 합계를 그대로 둔다. */
  var capexTotalBeforeDetail = null, opexTotalBeforeDetail = null;
  function anyAmount(items) {
    return items.some(function (it) { return it.amountEok !== null && it.amountEok !== undefined && it.amountEok !== ''; });
  }
  function toggleCapexDetail(on) {
    capexDetailOn = on;
    var capexEl = $('[data-k="capexEok"]');
    if (on && capexEl) capexTotalBeforeDetail = capexEl.value;
    if (capexEl) capexEl.readOnly = on;
    if (on) {
      buildCapexItemGrid();
      // 항목이 다 비어 있으면 합계를 0으로 덮지 않고 기존 총액을 유지한다.
      if (anyAmount(CAPEX_ITEMS)) updateCapexItemSum();
    } else {
      var box = $('#capexItemBox'); if (box) box.innerHTML = '';
      if (capexEl && !anyAmount(CAPEX_ITEMS) && capexTotalBeforeDetail !== null) {
        capexEl.value = capexTotalBeforeDetail;
        // 총사업비에 딸린 것들(지출 스케줄·자기자본비율)이 같이 되살아나야 한다.
        capexEl.dispatchEvent(new Event('change', { bubbles: true }));
        capexEl.dispatchEvent(new Event('input', { bubbles: true }));
      }
      capexTotalBeforeDetail = null;
    }
  }

  function opexItemRow(it, idx) {
    var tr = document.createElement('tr');
    function cell(type, val, f) {
      var td = document.createElement('td');
      var input = document.createElement('input');
      input.type = type; if (type === 'number') input.step = 'any';
      input.value = val === null || val === undefined ? '' : val;
      input.dataset.opexIdx = idx; input.dataset.opexF = f;
      td.appendChild(input);
      return td;
    }
    tr.appendChild(cell('text', it.name, 'name'));
    tr.appendChild(cell('number', it.amountEok, 'amountEok'));
    // MW당 금액은 입력칸이 아니라 위 금액을 설비용량으로 나눈 참고치일
    // 뿐이다 — 입력 가능한 것처럼 보이면 헷갈리니 입력칸(input) 대신
    // 회색 텍스트로만 보여준다(원본 Assum!E341 "per MW" 보조열과 같은
    // 성격, 다만 원본과 반대로 여긴 입력이 아니라 계산 결과 표시).
    var mwTd = document.createElement('td');
    var mwSpan = document.createElement('span');
    mwSpan.className = 'mwref';
    mwSpan.dataset.opexMwref = idx;
    mwSpan.textContent = '—';
    mwTd.appendChild(mwSpan); tr.appendChild(mwTd);
    tr.appendChild(cell('number', it.escal, 'escal'));
    var selTd = document.createElement('td');
    var sel = document.createElement('select');
    sel.innerHTML = '<option value="1">선순위</option><option value="0">후순위</option>';
    sel.value = it.senior === false ? '0' : '1';
    sel.dataset.opexIdx = idx; sel.dataset.opexF = 'senior';
    selTd.appendChild(sel); tr.appendChild(selTd);
    var rmTd = document.createElement('td');
    var rm = document.createElement('button');
    rm.type = 'button'; rm.className = 'rm'; rm.textContent = '×';
    rm.addEventListener('click', function () {
      if (OPEX_ITEMS.length <= 1) return;
      OPEX_ITEMS.splice(idx, 1);
      buildOpexItemGrid();
      updateOpexItemSum();
    });
    rmTd.appendChild(rm); tr.appendChild(rmTd);
    return tr;
  }

  function buildOpexItemGrid() {
    var box = $('#opexItemBox');
    if (!box) return;
    box.innerHTML = '';
    var t = el('table', 'tr');
    t.innerHTML = '<thead><tr><th>항목</th><th>연간금액<br>(억원/yr)</th><th>MW당<br>(참고)</th><th>상승률<br>(%/yr)</th><th>지급<br>순위</th><th></th></tr></thead>';
    var tb = document.createElement('tbody');
    OPEX_ITEMS.forEach(function (it, idx) { tb.appendChild(opexItemRow(it, idx)); });
    t.appendChild(tb);
    box.appendChild(t);
    box.appendChild(el('div', 'trlegend',
      '<b>MW당</b>: 입력칸이 아니라 왼쪽 금액을 위 "설비용량"으로 나눈 참고치입니다(자동 계산, 직접 입력 불가). ' +
      '<b>선순위</b>: 원리금 상환 전에 먼저 빠지는 비용 — 이 비용이 많을수록 원리금 상환여력(DSCR)이 낮게 계산됩니다. ' +
      '<b>후순위</b>: 원리금 상환 후 배당 전에 빠지는 비용 — DSCR 계산엔 영향 없음. 기본값은 전부 선순위입니다.'));
    var addBtn = document.createElement('button');
    addBtn.type = 'button'; addBtn.className = 'btn ghost'; addBtn.style.marginTop = '8px';
    addBtn.textContent = '+ 항목 추가';
    addBtn.addEventListener('click', function () {
      OPEX_ITEMS.push({ name: '항목' + (OPEX_ITEMS.length + 1), amountEok: null, escal: 0, senior: true });
      buildOpexItemGrid();
    });
    box.appendChild(addBtn);
    var sum = el('div', 'spendsum'); sum.id = 'opexItemSum';
    box.appendChild(sum);
    plantMismatchNote(box, opexItemsPlant, applyPlantOpexItems);
    updateOpexItemSum();
  }

  // 항목별 금액을 위 "설비용량"으로 나눈 MW당 참고치를 새로고침한다 —
  // 항목 금액이 바뀌거나 설비용량이 바뀔 때마다 호출.
  function updateOpexMWRefs() {
    var capMW = Number(($('[data-k="capacityMW"]') || {}).value) || 0;
    Array.prototype.slice.call(document.querySelectorAll('#opexItemBox [data-opex-mwref]')).forEach(function (span) {
      var idx = span.dataset.opexMwref;
      var amtEl = document.querySelector('#opexItemBox [data-opex-f="amountEok"][data-opex-idx="' + idx + '"]');
      var amt = amtEl && amtEl.value !== '' ? Number(amtEl.value) : null;
      span.textContent = (amt != null && capMW > 0) ? (amt / capMW).toFixed(3) + '억원/MW' : '—';
    });
  }

  function readOpexItemsDetailed() {
    var trs = Array.prototype.slice.call(document.querySelectorAll('#opexItemBox tbody tr'));
    return trs.map(function (tr) {
      var nameEl = tr.querySelector('[data-opex-f="name"]');
      var amtEl = tr.querySelector('[data-opex-f="amountEok"]');
      var escalEl = tr.querySelector('[data-opex-f="escal"]');
      var seniorEl = tr.querySelector('[data-opex-f="senior"]');
      return {
        name: nameEl.value,
        amountEok: amtEl.value === '' ? null : Number(amtEl.value),
        escal: escalEl.value === '' ? 0 : Number(escalEl.value),
        senior: seniorEl.value === '1'
      };
    });
  }

  function updateOpexItemSum() {
    OPEX_ITEMS = readOpexItemsDetailed();
    var sum = OPEX_ITEMS.reduce(function (a, it) { return a + (it.amountEok || 0); }, 0);
    var box = $('#opexItemSum');
    if (box) box.innerHTML = '<span>항목 합계(1년차 기준)</span><span>' + sum.toFixed(2) + '억원/yr</span>';
    if (opexDetailOn && anyAmount(OPEX_ITEMS)) {   // 위 updateCapexItemSum 주석 참조
      var opexEl = $('[data-k="opexEok"]');
      opexEl.value = sum.toFixed(2);
      opexEl.dispatchEvent(new Event('change', { bubbles: true }));
    }
    updateOpexMWRefs();
  }

  function toggleOpexDetail(on) {
    opexDetailOn = on;
    var opexEl = $('[data-k="opexEok"]');
    if (on && opexEl) opexTotalBeforeDetail = opexEl.value;
    if (opexEl) opexEl.readOnly = on;
    if (on) {
      buildOpexItemGrid();
      if (anyAmount(OPEX_ITEMS)) updateOpexItemSum();   // 위 toggleCapexDetail 주석 참조
    } else {
      var box = $('#opexItemBox'); if (box) box.innerHTML = '';
      if (opexEl && !anyAmount(OPEX_ITEMS) && opexTotalBeforeDetail !== null) {
        opexEl.value = opexTotalBeforeDetail;
      }
      opexTotalBeforeDetail = null;
    }
  }

  function buildTrancheGrid() {
    var box = $('#trbox');
    box.innerHTML = ''; // × 삭제로 재호출될 때 이전 표가 안 지워지고 쌓이던 버그 방지
    var t = el('table', 'tr');
    // 열 폭을 고정 배분 — "트랜치"(선순위A 등) 라벨이 줄바꿈되던 문제와
    // "방식" 드롭다운(원리금균등 등) 글자가 잘리던 문제를 같이 해결.
    t.innerHTML = '<colgroup>' +
      '<col style="width:10%"><col style="width:12%"><col style="width:8%">' +
      '<col style="width:10%"><col style="width:10%"><col style="width:8%">' +
      '<col style="width:8%"><col style="width:28%"><col style="width:6%">' +
      '</colgroup>' +
      '<thead><tr>' +
      '<th>트랜치</th><th>금액(억원)</th><th>투입순서</th><th>건설금리(%)</th><th>운영금리(%)</th>' +
      '<th>거치(yr)</th><th>상환(yr)</th><th>방식</th><th></th></tr></thead>';
    var tb = document.createElement('tbody');
    TRANCHES.forEach(function (tr, ti) {
      var row = document.createElement('tr');
      var cells = [
        ['name', tr.name, 'text'],
        ['amountEok', tr.amountEok, 'number'],
        ['order', tr.order, 'number'],
        ['rateC', tr.rateO, 'number'],
        ['rateO', tr.rateO, 'number'],
        ['graceYears', tr.graceYears, 'number'],
        ['repayYears', tr.repayYears, 'number']
      ];
      cells.forEach(function (c, idx) {
        var td = document.createElement('td');
        if (idx === 0) { td.textContent = c[1]; row.appendChild(td); return; }
        var input = document.createElement('input');
        input.type = c[2] === 'text' ? 'text' : 'number';
        input.step = 'any';
        input.value = c[1];
        input.dataset.tr = tr.key; input.dataset.f = c[0];
        td.appendChild(input);
        row.appendChild(td);
      });
  var mtd = document.createElement('td');
      var sel = document.createElement('select');
      sel.innerHTML = '<option value="1">원금균등</option><option value="2">원리금균등</option>';
      sel.dataset.tr = tr.key; sel.dataset.f = 'method';
      mtd.appendChild(sel);
      row.appendChild(mtd);
      // 해당 없는 트랜치는 지울 수 있게 — 사업자구성/민감도 분석과
      // 같은 × 버튼 패턴. 최소 1개는 남겨야 함(전부 지우면 부채가
      // 아예 없는 상태가 돼서 계산 자체는 되지만 UI가 텅 비어버림).
      var rmTd = document.createElement('td');
      var rm = document.createElement('button');
      rm.type = 'button'; rm.className = 'rm'; rm.textContent = '×';
      rm.addEventListener('click', function () {
        if (TRANCHES.length <= 1) return;
        TRANCHES.splice(ti, 1);
        buildTrancheGrid();
      });
      rmTd.appendChild(rm); row.appendChild(rmTd);
      tb.appendChild(row);
    });
    t.appendChild(tb);
    box.appendChild(t);
  }

  // 트랜치 조건을 몰라도(또는 대략적인 민감도 확인만 하고 싶을 때) 쓰는
  /* ---------- 조달 규모 자동 산정 ----------
     조달해야 하는 돈(소요액)은 공사비만이 아니다:
        소요액 = 총사업비 + DSRA 최초적립액 + 건설이자(IDC)
     그런데 건설이자는 "얼마를 빌렸는지"로 정해지고, 빌릴 금액은 다시 건설이자를
     포함한 소요액으로 정해진다 — 서로를 참조하는 순환이라 한 번에 못 구한다.
     그래서 반복해서 수렴시킨다(엔진의 같은 구조가 2회에 수렴하므로 3회면 충분).

     예전엔 간편설정이 `부채 = 총사업비 - 자본금`으로만 잡아서 DSRA와 건설이자만큼
     (부남호 294억) 조달이 비었다. 엔진은 약정 한도까지만 인출하므로 그 부족분이
     조용히 사라져 이자·원리금이 과소계상되고 IRR이 좋게 나왔다
     (2026-10-02 사용자 발견). 이제 소요액 기준으로 산정하고, 부족하면 생성을 막는다. */
  var debtAutoSized = false;   // 부채 금액이 자동 산정된 상태인가(사용자가 직접 고치면 해제)
  var sensInputFingerprint = null;   // 민감도를 돌린 시점의 입력 지문(바뀌면 결과 무효화)

  /* 입력이 바뀌면 민감도 결과를 버린다.
     민감도는 화면 입력을 직접 읽으므로 "생성 → 민감도" 순서는 상관없지만, 민감도를 돌린 뒤
     입력을 고치면 표와 엑셀 민감도 시트가 옛 입력 기준으로 남는다. 거래처로 나가는 자료에
     그게 섞이면 치명적이라 결과를 지우고 다시 실행하라고 알린다(2026-10-02 사용자 질문). */
  function invalidateSensIfInputChanged() {
    if (!lastSensResults || sensInputFingerprint == null) return;
    var now;
    try { now = JSON.stringify(snapshotState()); } catch (e) { return; }
    if (now === sensInputFingerprint) return;
    lastSensResults = null; sensInputFingerprint = null;
    var box = $('#sensResults');
    if (box) {
      box.innerHTML = '';
      var w = el('div', 'sensStale');
      w.appendChild(el('div', 'sensStaleT', '입력이 바뀌어 민감도 결과를 지웠습니다'));
      w.appendChild(el('div', 'sensStaleB', '아래 "민감도 분석 실행"을 다시 누르세요 — 다시 실행하기 전에는 엑셀에 민감도 시트가 들어가지 않습니다.'));
      box.appendChild(w);
    }
  }

  // 부채 총액을 트랜치에 배분 — 금액이 든 트랜치들의 비율 유지, 전부 0이면 첫 트랜치로
  function scaleDebt(trs, totalEok) {
    var sum = trs.reduce(function (a, t) { return a + (Number(t.amountEok) || 0); }, 0);
    return trs.map(function (t, i) {
      var amt = sum > 1e-9 ? totalEok * (Number(t.amountEok) || 0) / sum : (i === 0 ? totalEok : 0);
      return Object.assign({}, t, { amountEok: amt });
    });
  }

  /* 입력 객체(inp)의 조달을 소요액에 맞춘다 — 자기자본비율 ratio 고정.
     화면과 무관하게 동작해야 하므로(민감도 시나리오용) DOM 을 읽지 않는다.
     건설이자가 순환이라 3회 반복으로 수렴시킨다. */
  function sizeFundingForInput(inp, ratio) {
    var capex = Number(inp.capexEok) || 0, dsra = Number(inp.dsraEok) || 0;
    var need = capex + dsra;
    for (var it = 0; it < 3; it++) {
      var eq = need * ratio;
      var debt = Math.max(0, need - eq);
      inp.equityEok = eq;
      inp.tranches = scaleDebt(inp.tranches || [], debt);
      var idc = 0;
      try { idc = (M.computeModel(inp).idc || 0) / 100; } catch (e) { break; }
      var next = capex + dsra + idc;
      var done = Math.abs(next - need) < 1e-6;
      need = next;
      if (done) break;
    }
    var eq2 = need * ratio;
    inp.equityEok = eq2;
    inp.tranches = scaleDebt(inp.tranches || [], Math.max(0, need - eq2));
    return inp;
  }

  // 화면 입력으로 모델을 시험 실행해 건설이자를 얻고, 소요액을 되짚는다
  function fundingNeedEok(equityEok, debtEok) {
    var core = readCore();
    var capex = Number(core.capexEok) || 0;
    var dsra = Number(core.dsraEok) || 0;
    var need = capex + dsra, idc = 0;
    for (var it = 0; it < 3; it++) {
      var eq = equityEok != null ? equityEok : (Number(core.equityEok) || 0);
      var debt = debtEok != null ? debtEok : Math.max(0, need - eq);
      var probe;
      try {
        probe = M.computeModel(Object.assign({}, core, {
          ppy: 4, equityOrder: 1, spendCurve: readSpendCurve(),
          equityEok: eq, taxMode: 1, localSurtaxRate: 10,
          tariffTracks: buildTariffTracks(core),
          tranches: scaleDebt(readTranches(), debt)
        }));
      } catch (e) { break; }
      idc = (probe.idc || 0) / 100;
      var next = capex + dsra + idc;
      var done = Math.abs(next - need) < 1e-6;
      need = next;
      if (done) break;
    }
    return { need: need, idcEok: idc, capexEok: capex, dsraEok: dsra };
  }

  /* 조달을 소요액에 맞춘다 — 자기자본비율을 고정하고 자본금·부채를 같이 늘린다.
     비율 칸이 비어 있으면 (현재 자본금 ÷ 소요액)을 비율로 보고 유지한다. */
  function autoSizeFunding(opts) {
    var ratioEl = $('[data-k="equityRatioPct"]'), eqEl = $('[data-k="equityEok"]');
    var f = fundingNeedEok(null, null);
    var ratio = (ratioEl && ratioEl.value !== '') ? Number(ratioEl.value) / 100 : null;
    if (ratio == null) {
      var eqNow = Number(eqEl.value) || 0;
      ratio = f.need > 0 ? eqNow / f.need : 0;
    }
    // 자본금이 바뀌면 인출 순서 때문에 건설이자도 조금 움직인다 — 한 번 더 되짚는다
    var f2 = fundingNeedEok(f.need * ratio, null);
    var eq = f2.need * ratio;
    var debt = Math.max(0, f2.need - eq);
    suppressDirty = true;
    try {
      setVal('[data-k="equityEok"]', +eq.toFixed(2));
      if (ratioEl) ratioEl.value = (ratio * 100).toFixed(2);
      var scaled = scaleDebt(readTranches(), debt);
      TRANCHES.forEach(function (tr, i) {
        setVal('input[data-tr="' + tr.key + '"][data-f="amountEok"]', +scaled[i].amountEok.toFixed(5));
      });
    } finally { suppressDirty = false; }
    debtAutoSized = true;
    if (usingPreset) usingPreset = false;
    if (!opts || !opts.silent) {
      toast('조달을 소요액 ' + f0(f2.need) + '억원(총사업비 ' + f0(f2.capexEok) + ' + DSRA ' +
        f0(f2.dsraEok) + ' + 건설이자 ' + f0(f2.idcEok) + ')에 맞췄습니다 — 자기자본 ' + f0(eq) +
        '억(' + (ratio * 100).toFixed(1) + '%) · 부채 ' + f0(debt) + '억');
    }
    return { need: f2.need, equityEok: eq, debtEok: debt };
  }

  // 트랜치 표준조건(순서·금리·거치·상환·방식)만 세팅 — 금액은 건드리지 않는다
  function applyTrancheStdTerms(std) {
    suppressDirty = true;
    try {
      TRANCHES.forEach(function (tr) {
        setVal('input[data-tr="' + tr.key + '"][data-f="order"]', 1);
        setVal('input[data-tr="' + tr.key + '"][data-f="rateC"]', std.rateC);
        setVal('input[data-tr="' + tr.key + '"][data-f="rateO"]', std.rateO);
        setVal('input[data-tr="' + tr.key + '"][data-f="graceYears"]', std.graceYears);
        setVal('input[data-tr="' + tr.key + '"][data-f="repayYears"]', std.repayYears);
        setVal('select[data-tr="' + tr.key + '"]', std.method);
      });
    } finally { suppressDirty = false; }
  }

  // 간편설정 — 부채 전액(소요액-자본금)을 선순위A 하나로 몰아넣고
  // 나머지는 0으로 비워서 표준적인 조건(5.5%/5.5%, 거치2년, 상환15년,
  // 원금균등)으로 즉시 계산 가능하게 만든다. 스프레드곡선의
  // "균등분배로 재설정"과 같은 성격의 단순화 버튼.
  function quickFillTranches() {
    var std = { rateC: 5.5, rateO: 5.5, graceYears: 2, repayYears: 15, method: 1 };
    // 금리·거치·상환이 건설이자(=소요액)에 영향을 주므로 표준조건을 먼저 깐다
    applyTrancheStdTerms(std);
    var r = autoSizeFunding({ silent: true });
    suppressDirty = true;
    try {
      TRANCHES.forEach(function (tr, idx) {
        setVal('input[data-tr="' + tr.key + '"][data-f="amountEok"]', idx === 0 ? +r.debtEok.toFixed(5) : 0);
      });
    } finally { suppressDirty = false; }
    if (usingPreset) { usingPreset = false; }
    debtAutoSized = true;
    toast('부채 ' + f0(r.debtEok) + '억원(소요액 ' + f0(r.need) + '억 − 자기자본 ' + f0(r.equityEok) +
      '억)을 선순위A 하나로 단순화했습니다 — 소요액에는 DSRA·건설이자가 포함됩니다');
  }

  /* ---------- 사업자(출자자) 구성 ----------
     자본금을 나눠 낼 여러 출자자를 이름+지분율로 입력받는다. 모든 출자자는
     지분율만큼 자본금 납입·배당 수령에 비례 참여한다고 가정(pro-rata). */
  function shRow(sh, idx) {
    var row = el('div', 'shrow');
    var name = document.createElement('input');
    name.type = 'text'; name.value = sh.name; name.dataset.shName = idx;
    var stake = document.createElement('input');
    stake.type = 'number'; stake.step = 'any'; stake.value = sh.stakePct; stake.dataset.shStake = idx;
    var unit = el('span', 'unit', '%');
    row.appendChild(name); row.appendChild(stake); row.appendChild(unit);
    var rm = document.createElement('button');
    rm.type = 'button'; rm.className = 'rm'; rm.textContent = '×';
    rm.addEventListener('click', function () {
      if (SHAREHOLDERS.length <= 1) return;
      SHAREHOLDERS.splice(idx, 1);
      buildShareholderGrid();
    });
    row.appendChild(rm);
    return row;
  }

  function buildShareholderGrid() {
    var box = $('#shbox');
    box.innerHTML = '';
    // 입력칸 위에 "출자자명"/"지분율" 열 제목을 달아준다 — 아래 행과
    // 같은 flex 비율(1.4/0.7)로 맞추고, unit·삭제버튼 자리만큼 빈 칸을
    // 채워서 좌우 정렬이 어긋나지 않게 한다.
    var head = el('div', 'shrow shrow-head');
    head.appendChild(el('span', 'shrow-label', '출자자명'));
    head.appendChild(el('span', 'shrow-label', '지분율'));
    head.appendChild(el('span', 'unit', ''));
    var spacer = el('span'); spacer.style.width = '30px'; spacer.style.flex = '0 0 auto';
    head.appendChild(spacer);
    box.appendChild(head);
    SHAREHOLDERS.forEach(function (sh, idx) { box.appendChild(shRow(sh, idx)); });
    updateShareholderSum();
  }

  function readShareholders() {
    var names = Array.prototype.slice.call(document.querySelectorAll('[data-sh-name]'));
    return names.map(function (e) {
      var idx = e.dataset.shName;
      var stakeEl = document.querySelector('[data-sh-stake="' + idx + '"]');
      return { name: e.value || ('출자자' + (Number(idx) + 1)), stakePct: Number(stakeEl.value) || 0 };
    });
  }

  function updateShareholderSum() {
    var box = $('#shsum');
    if (!box) return;
    var list = readShareholders();
    // 화면에 그려진 값을 상태(SHAREHOLDERS)에도 반영해둔다(재렌더 시 유지).
    SHAREHOLDERS = list;
    var sum = list.reduce(function (a, s) { return a + (s.stakePct || 0); }, 0);
    var ok = Math.abs(sum - 100) < 0.01;
    box.className = 'spendsum ' + (ok ? 'ok' : 'bad');
    box.innerHTML = '<span>지분율 합계: ' + sum.toFixed(2) + '%</span><span>' + (ok ? '100% — 일치' : '100%와 차이 ' + (sum - 100).toFixed(2) + '%p') + '</span>';
  }

  /* ---------- 민감도 분석 ----------
     화면 입력(일반 경로) 기준으로 판매단가/총투자비/운영비/이자율을
     시나리오별로 조정해 여러 번 재계산한다. 프리셋(당진 FS)은 실측
     분기 데이터(periodOverrides)로 결과가 고정돼 있어 이 조정들이
     반영되지 않으므로 의도적으로 막는다. */
  function sensRow(sc, idx) {
    var tr = document.createElement('tr');
    function cell(val, f, isText) {
      var td = document.createElement('td');
      var input = document.createElement('input');
      input.type = isText ? 'text' : 'number'; input.step = 'any';
      input.value = val === null || val === undefined ? '' : val;
      input.dataset.sensIdx = idx; input.dataset.sensF = f;
      td.appendChild(input);
      return td;
    }
    tr.appendChild(cell(sc.name, 'name', true));
    tr.appendChild(cell(sc.tariffAbs, 'tariffAbs'));
    tr.appendChild(cell(sc.capexAbs, 'capexAbs'));
    tr.appendChild(cell(sc.opexAbs, 'opexAbs'));
    tr.appendChild(cell(sc.rateAbs, 'rateAbs'));
    // "불러오기"는 Base행에서만 의미가 있다 — Case는 사용자가 직접
    // 값을 채우는 행이라 버튼을 안 둔다.
    var pullTd = document.createElement('td');
    if (sc.name === 'Base') {
      var pull = document.createElement('button');
      pull.type = 'button'; pull.className = 'pull'; pull.title = '위 "사업 기본 가정" 입력값을 그대로 불러와 채우기';
      pull.textContent = '불러오기';
      pull.addEventListener('click', function () { pullFromForm(idx); });
      pullTd.appendChild(pull);
    }
    tr.appendChild(pullTd);
    var rmTd = document.createElement('td');
    var rm = document.createElement('button');
    rm.type = 'button'; rm.className = 'rm'; rm.textContent = '×';
    rm.addEventListener('click', function () {
      if (SENS_ROWS.length <= 1) return;
      SENS_ROWS.splice(idx, 1);
      buildSensGrid();
    });
    rmTd.appendChild(rm);
    tr.appendChild(rmTd);
    return tr;
  }

  // 그 순간의 위 "사업 기본 가정" 값(판매단가/총사업비/운영비, 금리는
  // 금액이 가장 큰 트랜치의 운영금리를 대표값으로)을 해당 시나리오 행에
  // 그대로 채워넣는다 — Base 행을 실제 숫자로 눈에 보이게 채우고 싶을 때,
  // 또는 다른 행을 "위 값에서 살짝만 바꿔보고 싶을 때" 시작점으로 쓴다.
  function pullFromForm(idx) {
    var row = document.querySelectorAll('#sensBox tbody tr')[idx];
    if (!row) return;
    setVal2(row, 'tariffAbs', $('[data-k="tariff"]').value);
    setVal2(row, 'capexAbs', $('[data-k="capexEok"]').value);
    setVal2(row, 'opexAbs', $('[data-k="opexEok"]').value);
    var tranches = readTranches();
    var maxT = null;
    tranches.forEach(function (t) { if (!maxT || t.amountEok > maxT.amountEok) maxT = t; });
    setVal2(row, 'rateAbs', maxT && maxT.amountEok > 0 ? maxT.rateO : '');
  }
  function setVal2(row, f, v) { var e = row.querySelector('[data-sens-f="' + f + '"]'); if (e) e.value = v; }

  function buildSensGrid() {
    var box = $('#sensBox');
    box.innerHTML = '';
    var t = el('table', 'tr');
    t.innerHTML = '<thead><tr><th>시나리오</th><th>판매단가(원/kWh)</th><th>총사업비(억원)</th><th>운영비(억원)</th><th>금리(%)</th><th></th><th></th></tr></thead>';
    var tb = document.createElement('tbody');
    SENS_ROWS.forEach(function (sc, idx) { tb.appendChild(sensRow(sc, idx)); });
    t.appendChild(tb);
    box.appendChild(t);
  }

  // 빈 칸은 "위 사업 기본가정 값을 그대로 쓴다"는 뜻이라 null로 남긴다
  // (Number('')=0으로 바뀌면 "0으로 강제 지정"과 구분이 안 되므로).
  function readSensRows() {
    var trs = Array.prototype.slice.call(document.querySelectorAll('#sensBox tbody tr'));
    return trs.map(function (tr) {
      var o = {};
      Array.prototype.slice.call(tr.querySelectorAll('input')).forEach(function (input) {
        var f = input.dataset.sensF;
        if (f === 'name') { o[f] = input.value; return; }
        o[f] = input.value === '' ? null : Number(input.value);
      });
      return o;
    });
  }

  // 시나리오 값은 델타(증감)가 아니라 절대값이다 — 빈 칸이면 위 "사업 기본
  // 가정"에 입력한 값을 그대로 쓰고, 채워져 있으면 그 값으로 완전히
  // 대체한다. 판매단가·운영비는 tariffTracks/opexItems가 있을 때 그
  // 항목들도 같은 비율로 같이 조정, 금리는 모든 트랜치의 건설·운영금리를
  // 동일하게 덮어쓴다.
  function applyScenario(baseInp, sc) {
    var c = JSON.parse(JSON.stringify(baseInp));
    if (sc.tariffAbs != null) {
      var tRatio = c.tariff > 0 ? sc.tariffAbs / c.tariff : 1;
      if (c.tariffTracks) c.tariffTracks.forEach(function (t) { t.price = t.price * tRatio; });
      c.tariff = sc.tariffAbs;
    }
    if (sc.capexAbs != null) c.capexEok = sc.capexAbs;
    if (sc.opexAbs != null) {
      var oRatio = c.opexEok > 0 ? sc.opexAbs / c.opexEok : 1;
      if (c.opexItems) c.opexItems.forEach(function (it) { it.annualKRWm = it.annualKRWm * oRatio; });
      c.opexEok = sc.opexAbs;
    }
    if (sc.rateAbs != null && c.tranches) {
      c.tranches.forEach(function (t) { t.rateC = sc.rateAbs; t.rateO = sc.rateAbs; });
    }
    return c;
  }

  /* 판매단가 트랙 구성 — RPS(SMP+REC)/PPA 매출 이원화.
     SMP와 REC는 대금 회수 시차가 다르므로(SMP 통상 1개월, REC는 발급·거래
     절차가 더 붙어 2개월) 하나로 합치지 않고 **별도 트랙으로 분리**한다.
     매출 총액은 합쳐도 나눠도 같지만(gen×share×smp + gen×share×w·rec =
     gen×share×(smp+w·rec)), 분리해야 트랙별 회수 시차를 각각 적용할 수 있다.
     RPS 비중이 0이면 전량 PPA라 PPA 트랙 하나만 만든다. */
  /* 발전량 산식 입력 정규화 — 엔진은 dailyHours가 있으면 태양광 산식(용량×
     일조시간×365), 없으면 이용률 산식(용량×8760×이용률×가동률)을 쓴다.
     화면에서 발전원별로 다른 칸을 받으므로 여기서 엔진 입력 형태로 맞춘다. */
  function applyPlantGen(c) {
    if (plantType === 'wind') {
      c.dailyHours = undefined;              // 이용률 경로를 타게 한다
      c.capacityFactor = c.capacityFactorPct;
      c.availability = c.availability;
    } else {
      c.capacityFactor = undefined;          // dailyHours 우선
      c.availability = undefined;
    }
    return c;
  }

  function buildTariffTracks(c) {
    var rps = (c.rpsShare || 0) / 100;
    var tracks = [];
    if (rps > 0) {
      tracks.push({ name: 'SMP', share: rps, price: c.smpPrice, escal: c.tariffEscal, arLagMonths: c.arLagSMP });
      tracks.push({ name: 'REC', share: rps, price: (c.recWeight || 1) * c.recPrice, escal: c.tariffEscal, arLagMonths: c.arLagREC });
    }
    if (rps < 1) {
      tracks.push({ name: 'PPA', share: 1 - rps, price: c.tariff, escal: c.tariffEscal, arLagMonths: c.arLagPPA });
    }
    return tracks;
  }

  function buildBaseInp() {
    var core = readCore();
    var tranches = readTranches();
    var spendCurve = readSpendCurve();
    var baseInp = Object.assign({}, core, {
      ppy: 4, spendCurve: spendCurve, equityOrder: 1,
      tranches: tranches.map(function (t) {
        return { name: t.name, amountEok: t.amountEok, order: t.order, rateC: t.rateC, rateO: t.rateO, graceYears: t.graceYears, repayYears: t.repayYears, method: t.method };
      }),
      taxMode: 1, localSurtaxRate: 10
    });
    baseInp.tariffTracks = buildTariffTracks(baseInp);
    applyPlantGen(baseInp);
    if (opexDetailOn) {
      baseInp.opexItems = readOpexItemsDetailed().map(function (it) {
        return { name: it.name, annualKRWm: (it.amountEok || 0) * 100, escal: it.escal, senior: it.senior };
      });
    }
    baseInp.shareholders = readShareholders();
    return baseInp;
  }

  function runSensitivity() {
    var wasPreset = usingPreset;
    if (usingPreset) {
      // 실측치(periodOverrides) 기준으로는 판매단가/총사업비/운영비/금리를
      // 바꿔도 결과가 그대로라 민감도 분석 자체가 의미 없다. 막는 대신
      // 프리셋을 해제하고 일반 계산식 기준으로 자동 전환해서 실행한다.
      usingPreset = false;
    }
    var baseInp = buildBaseInp();

    // Base도 다른 행과 똑같은 일반 시나리오 행이다 — 빈 칸이면 applyScenario가
    // 알아서 위 폼 값을 그대로 쓰므로 특별 취급이 필요 없다.
    SENS_ROWS = readSensRows();
    /* 총사업비·금리를 바꾸면 조달 소요액(= 총사업비 + DSRA + 건설이자)도 바뀐다.
       예전엔 트랜치 약정을 그대로 둔 채 계산해서, 사업비를 올린 시나리오가
       "늘어난 사업비를 조달하지 않은" 상태로 돌아갔다 — 이자가 안 붙어
       Equity IRR 이 오히려 좋아지는 거꾸로 된 결과가 나왔다(2026-10-02 사용자 발견:
       EPC 를 올린 Case1 의 배당 IRR 이 Base 보다 높게). 시나리오마다 조달을
       소요액에 맞추고, 자기자본비율은 기준 케이스와 같게 유지한다. */
    var baseNeed = (Number(baseInp.capexEok) || 0) + (Number(baseInp.dsraEok) || 0) +
      (function () { try { return (M.computeModel(baseInp).idc || 0) / 100; } catch (e) { return 0; } })();
    var baseRatio = baseNeed > 0 ? (Number(baseInp.equityEok) || 0) / baseNeed : 0;
    var results = SENS_ROWS.map(function (sc) {
      try {
        var scInp = sizeFundingForInput(applyScenario(baseInp, sc), baseRatio);
        var m = M.computeModel(scInp);
        return { name: sc.name, sc: sc, kpi: m.kpi, verdict: sensVerdictParts(m.kpi),
          equityEok: scInp.equityEok, debtEok: (scInp.tranches || []).reduce(function (a, t) { return a + (t.amountEok || 0); }, 0) };
      } catch (e) {
        return { name: sc.name, sc: sc, error: e.message };
      }
    });
    lastSensResults = results;
    // 민감도를 돌린 시점의 입력 지문 — 이후 입력이 바뀌면 이 결과는 묵은 값이 된다.
    try { sensInputFingerprint = JSON.stringify(snapshotState()); } catch (e) { sensInputFingerprint = null; }
    renderSensResults(results);
    toast(
      (wasPreset ? '프리셋을 해제하고 일반 계산식 기준으로 전환했습니다 — ' : '') +
      '민감도 분석 완료 — ' + results.length + '개 시나리오'
    );
  }

  /* 시나리오 판정 — 거래처·이해관계자가 그대로 읽을 수 있게 "등급 + 평이한 사유"로 쓴다.
     재무 약어만 쓰면(IRR 과대 / NPV 음) 숫자만 보고 "낮지만 되는구나"로 오해한다.
        적격   : DSCR 1.2 이상 · 운영 중 자금부족 없음 · NPV 0 이상
        조건부 : 위 중 DSCR 여유만 부족(1.0~1.2)
        부적격 : 원리금 상환 불가(DSCR<1.0) · 운영 중 자금부족 · 요구수익률 미달(NPV<0)
     엑셀(xlsxbuild2.js)의 같은 판정 문구와 맞춰 둘 것. */
  function sensVerdictParts(k) {
    var why = [], grade = '적격';
    if (k.minDSCRAnnual !== null && k.minDSCRAnnual < 1) {
      grade = '부적격';
      why.push('영업현금으로 원리금 상환 불가 (DSCR ' + k.minDSCRAnnual.toFixed(2) + ', 기준 1.0 이상)');
    } else if (k.minDSCRAnnual !== null && k.minDSCRAnnual < 1.2) {
      grade = '조건부';
      why.push('원리금 상환 여유 부족 (DSCR ' + k.minDSCRAnnual.toFixed(2) + ', 금융권 통상 1.2 이상)');
    }
    if (k.totalEquityInject > 1) {
      grade = '부적격';
      why.push('운영 중 자금 부족으로 추가 출자 ' + feok(k.totalEquityInject) + '억 필요 (왼쪽 수익률에 이미 반영된 값)');
    }
    if (k.npv !== null && k.npv < 0) {
      grade = '부적격';
      why.push('요구수익률 미달 — NPV ' + feok(k.npv) + '억');
    }
    return { grade: grade, why: why.join(' · ') || '금융 조달 가능·투자 기준 충족' };
  }
  function sensVerdict(k) {
    var v = sensVerdictParts(k);
    var color = v.grade === '적격' ? 'var(--good)' : (v.grade === '조건부' ? 'var(--warn)' : 'var(--bad)');
    return '<b style="color:' + color + '">' + v.grade + '</b><div style="color:var(--muted);font-size:10.5px;line-height:1.5">' + v.why + '</div>';
  }

  function renderSensResults(results) {
    var box = $('#sensResults');
    box.innerHTML = '';
    var t = el('table', 'tr');
    t.innerHTML = '<thead><tr><th>시나리오</th><th>Equity IRR(배당)</th><th>Equity IRR(FCFE)</th>' +
      '<th>Project IRR</th><th>최소DSCR</th><th>최저현금(억)</th><th>NPV(억원)</th><th>투자배수</th><th>판정 · 사유</th></tr></thead>';
    var tb = document.createElement('tbody');
    results.forEach(function (r) {
      var tr = document.createElement('tr');
      if (r.error) {
        tr.innerHTML = '<td>' + r.name + '</td><td colspan="8" style="color:var(--bad)">계산 실패: ' + r.error + '</td>';
      } else {
        var k = r.kpi;
        tr.innerHTML = '<td>' + r.name + '</td>' +
          '<td style="text-align:right">' + pct(k.dividendIRR) + '%</td>' +
          '<td style="text-align:right">' + pct(k.equityIRR) + '%</td>' +
          '<td style="text-align:right">' + pct(k.projectIRR) + '%</td>' +
          '<td style="text-align:right">' + (k.minDSCRAnnual === null ? '—' : k.minDSCRAnnual.toFixed(3)) + 'x</td>' +
          /* 운영 중 최저 보유현금 — 음수면 그 시나리오는 추가 출자·브리지 없이는 성립하지 않고
             같은 행의 Equity IRR 은 과대평가된 값이다. 표에 안 보이면 놓치게 되므로 같이 싣는다
             (2026-10-02 Case1 이 -171억인데 표에는 IRR 만 보였다). */
          '<td style="text-align:right' + (k.minCashClose < -1 ? ';color:var(--bad);font-weight:700' : '') + '">' +
            (k.minCashClose === null ? '—' : feok(k.minCashClose)) + '</td>' +
          '<td style="text-align:right">' + feok(k.npv) + '</td>' +
          '<td style="text-align:right">' + fx(k.equityMultiple) + '배</td>' +
          '<td style="font-size:11px">' + sensVerdict(k) + '</td>';
      }
      tb.appendChild(tr);
    });
    t.appendChild(tb);
    box.appendChild(t);
  }

  function buildSpendCurve() {
    var box = $('#spendbox');
    box.innerHTML = '';
    var cm = Number($('[data-k="constructionMonths"]').value) || 16;
    var nq = Math.max(1, Math.ceil(cm / 3));
    var capex = Number($('[data-k="capexEok"]').value) || 0;
    for (var i = 0; i < nq; i++) {
      var f = el('div', 'f');
      f.appendChild(el('label', null, (i + 1) + '분기'));
      var inw = el('div', 'in2');
      var input = document.createElement('input');
      input.type = 'number'; input.step = 'any';
      input.value = (capex / nq).toFixed(2);
      input.dataset.spend = i;
      inw.appendChild(input);
      inw.appendChild(el('span', 'unit', '억원'));
      f.appendChild(inw);
      box.appendChild(f);
    }
    updateSpendSum();
  }

  function updateSpendSum() {
    var box = $('#spendsum');
    if (!box) return;
    var capex = Number($('[data-k="capexEok"]').value) || 0;
    var sum = readSpendCurve().reduce(function (a, b) { return a + (b || 0); }, 0);
    var diff = sum - capex;
    var ok = Math.abs(diff) < 0.5;
    box.className = 'spendsum ' + (ok ? 'ok' : 'bad');
    box.innerHTML = '<span>지출 합계: ' + sum.toFixed(2) + '억원</span><span>총사업비: ' + capex.toFixed(2) + '억원' +
      (ok ? ' — 일치' : ' — 차이 ' + diff.toFixed(2) + '억원') + '</span>';
  }

  // RPS 비중이 0(전량 PPA)이면 REC 가중치는 의미가 없으므로 1로 고정하고
  // 입력을 잠근다 — RPS 비중이 0보다 커지면 다시 편집 가능하게 푼다.
  function updateRecWeightState() {
    var rpsEl = $('[data-k="rpsShare"]');
    var rwEl = $('[data-k="recWeight"]');
    if (!rpsEl || !rwEl) return;
    var rps = Number(rpsEl.value) || 0;
    if (rps <= 0) { rwEl.value = 1; rwEl.disabled = true; }
    else { rwEl.disabled = false; }
  }

  function readCore() {
    var inp = {};
    CORE.forEach(function (d) {
      if (d.type === 'display') return; // 계산 결과 표시용일 뿐 입력값이 아님
      var v = $('[data-k="' + d.k + '"]').value;
      inp[d.k] = d.type === 'text' ? v : Number(v);
    });
    return inp;
  }

  // 자본금(절대값) ↔ 자기자본비율(%, 총사업비 대비) 양방향 동기화.
  // fromRatio=true면 비율→자본금, false면 자본금→비율로 갱신한다.
  function syncEquityRatio(fromRatio) {
    var capexEl = $('[data-k="capexEok"]'), eqEl = $('[data-k="equityEok"]'), ratioEl = $('[data-k="equityRatioPct"]');
    if (!capexEl || !eqEl || !ratioEl) return;
    // 비율의 기준은 총사업비가 아니라 **총조달 소요액**(공사비 + DSRA + 건설이자)이다.
    // 금융권이 이 기준으로 보고, 조달을 여기 맞춰야 부족분이 안 생긴다.
    var need = fundingNeedEok(null, null).need;
    if (need <= 0) return;
    if (fromRatio) {
      if (ratioEl.value !== '') {
        eqEl.value = (need * Number(ratioEl.value) / 100).toFixed(2);
        // 자기자본비율은 "조달 구조"를 정하는 입력이다 — 자본금만 바꾸고 부채를 그대로 두면
        // 조달이 모자라 생성이 막힌다. 비율을 넣으면 부채까지 같이 맞춘다(비율대로 비례 배분).
        autoSizeFunding({ silent: true });
      }
    } else {
      ratioEl.value = (Number(eqEl.value) / need * 100).toFixed(2);
    }
  }
  function readTranches() {
    return TRANCHES.map(function (tr) {
      var o = { name: tr.name, method: Number($('select[data-tr="' + tr.key + '"]').value) };
      ['amountEok', 'order', 'rateC', 'rateO', 'graceYears', 'repayYears'].forEach(function (f) {
        o[f] = Number($('input[data-tr="' + tr.key + '"][data-f="' + f + '"]').value);
      });
      return o;
    });
  }
  function readSpendCurve() {
    return Array.prototype.slice.call(document.querySelectorAll('[data-spend]')).map(function (el2) {
      return Number(el2.value);
    });
  }

  /* ---------- 당진 FS 프리셋 ----------
     test/test_ops.js·scripts/sample2.js와 완전히 동일한 방식으로 reference.json
     (80개 분기 실측 오버라이드 + 세액공제/AMT + 배당 결의 타이밍)을 그대로
     엔진 입력으로 구성한다 — 이게 없으면 화면은 검증된 숫자를 재현하지 못한다. */
  var usingPreset = false, presetInp = null, suppressDirty = false;

  function buildDangjinInp(ref) {
    function findTranche(name) { return ref.tranches.find(function (t) { return t.name === name; }); }
    function scheduleFor(letter) {
      var s = ref.repaySchedule_case3[letter];
      return s ? s.map(function (p) { return p[1]; }) : null;
    }
    var trancheDefs = [['선순위A', 'A'], ['선순위B', 'B'], ['선순위C', 'C'], ['선순위D', null], ['후순위', null]];
    return {
      projectName: '당진 태양광발전', ppy: 4,
      capacityMW: ref.project.capacityMW,
      capacityFactor: ref.project.capacityFactor * 100,
      dailyHours: ref.project.dailyHours,
      degradation: ref.project.degradation * 100,
      auxRate: 0,
      constructionStart: ref.project.constructionStart,
      constructionMonths: ref.project.constructionMonths,
      operationYears: ref.project.operationYears,
      capexEok: ref.funding.TIC_exIDC / 100,
      dsraEok: ref.funding.DSRA / 100,
      opexItems: ref.opexItems.map(function (it) { return { name: it.name, annualKRWm: it.annualKRWm, escal: it.escalRate * 100, senior: it.senior }; }),
      spendCurve: ref.spendCurve_KRWm,
      // 당진 원본 Revenue!row18~20 "회수기일 가정" — PPA1/PPA2 각각 1개월.
      // 프리셋은 실측 오버라이드(wc)를 쓰므로 실제 계산엔 안 쓰이지만, 값을
      // 바꿔 프리셋이 풀렸을 때 같은 가정으로 이어지도록 넣어둔다.
      tariffTracks: ref.tariffTracks.map(function (t) { return { share: t.share, price: t.price, arLagMonths: 1 }; }),
      seasonality: (function () { var o = {}; Object.keys(ref.seasonality).forEach(function (m) { o[Number(m)] = ref.seasonality[m]; }); return o; })(),
      equityEok: ref.funding.equity / 100, equityOrder: ref.funding.equityOrder,
      tranches: trancheDefs.map(function (d) {
        var name = d[0], letter = d[1];
        var t = findTranche(name);
        return {
          name: t.name, amountEok: t.amount / 100, order: t.order,
          rateC: t.rateCon * 100, rateO: t.rateOp * 100,
          graceYears: t.graceYears, repayYears: t.repayYears, method: t.method,
          repayStart: letter ? t.repayStart : null,
          schedule: letter ? scheduleFor(letter) : null
        };
      }),
      depRatio: 95, depYears: 20, depBaseOverride: ref.depreciableBaseKRWm, taxMode: 1, taxFlat: 21, lossRate: 80,
      investmentCreditRate: ref.taxCredit.investmentCreditRate, amtRate: ref.taxCredit.amtRate,
      localSurtaxRate: ref.taxCredit.localSurtaxRate, creditSurtaxRate: ref.taxCredit.creditSurtaxRate,
      investmentCreditBaseByYear: ref.taxCredit.investmentCreditBaseByYear, preOpLossKRWm: ref.taxCredit.preOpLossKRWm,
      preOpLossByYear: ref.taxCredit.preOpLossByYear,
      extraTaxDeductionKRWm: ref.extraTaxDeductionKRWm, agentFeeKRWm: ref.agentFeeKRWm,
      periodOverrides: ref.periodOverrides,
      decomEok: ref.results.철거비 / 100,
      dsraMonths: 6, minCash: 10, divDSCR: 1.1, divCumDSCR: 1.15, divStartYear: 2, discount: 5.5,
      dividendMonth: ref.dividendMonth, firstDividendYear: ref.firstDividendYear
    };
  }

  function setVal(sel, v) { var e = $(sel); if (e) e.value = v; }

  function loadDangjin() {
    var ref = window.__DANGJIN_REFERENCE__;
    if (!ref) { toast('당진 실측 데이터가 이 빌드에 포함되어 있지 않습니다'); return; }
    setPlantType('solar');   // 당진은 태양광 프로젝트 — 풍력 상태였으면 되돌린다
    suppressDirty = true;
    setVal('[data-k="projectName"]', '당진 태양광발전');
    setVal('[data-k="capacityMW"]', ref.project.capacityMW);
    setVal('[data-k="dailyHours"]', ref.project.dailyHours);
    setVal('[data-k="degradation"]', ref.project.degradation * 100);
    setVal('[data-k="auxRate"]', 0);
    setVal('[data-k="constructionStart"]', ref.project.constructionStart);
    setVal('[data-k="constructionMonths"]', ref.project.constructionMonths);
    setVal('[data-k="operationYears"]', ref.project.operationYears);
    // 소수 둘째 자리로 자르지 않는다 — 아래에서 켜는 총사업비 항목 합계(=TIC_exIDC)와
    // 정확히 같아야 총사업비를 다시 쓰지 않고, 그래야 지출 스케줄 재생성이 일어나지 않는다.
    setVal('[data-k="capexEok"]', +(ref.funding.TIC_exIDC / 100).toFixed(6));
    setVal('[data-k="dsraEok"]', ref.funding.DSRA / 100);
    setVal('[data-k="equityEok"]', ref.funding.equity / 100);
    setVal('[data-k="tariff"]', ref.project.tariff_wavg);
    setVal('[data-k="tariffEscal"]', 0);
    // 당진 원본 Revenue!row18~20 "회수기일 가정" = PPA1/PPA2 각각 1개월
    setVal('[data-k="arLagPPA"]', 1);
    var totalOpex = ref.opexItems.reduce(function (a, it) { return a + it.annualKRWm; }, 0);
    setVal('[data-k="opexEok"]', (totalOpex / 100).toFixed(2));
    setVal('[data-k="opexEscal"]', 1.2); // 표시용 근사(항목별 실제 값은 프리셋 계산에 그대로 반영됨)

    // 운영비는 실제 항목별 실측치(reference.json opexItems)가 있으니
    // 그대로 채워서 항목별 입력 모드를 켜준다 — 위 opexEok 합계 필드도
    // 이 항목들의 합과 정확히 같은 값이라 서로 어긋나지 않는다.
    OPEX_ITEMS = ref.opexItems.map(function (it) {
      return { name: it.name, amountEok: it.annualKRWm / 100, escal: it.escalRate * 100, senior: it.senior !== false };
    });
    var opexToggleEl = $('#opexDetailToggle');
    if (opexToggleEl) opexToggleEl.checked = true;
    toggleOpexDetail(true);
    // 총사업비도 원본에 항목별 내역이 있다(Assum!B87:F99 '총투자비 상세내역').
    // 예전 주석은 "원본에 총액만 있다"고 했으나 사실이 아니었다 — 추출을
    // 빠뜨렸을 뿐. 12개 합계 = 총사업비(건설이자 제외)라 총액이 바뀌지 않고,
    // updateCapexItemSum 은 합계가 같으면 총사업비를 다시 쓰지 않으므로
    // 실측 지출 스케줄도 그대로 남는다.
    if (ref.capexItems && ref.capexItems.length) {
      CAPEX_ITEMS = ref.capexItems.map(function (it) { return { name: it.name, amountEok: +(it.amountKRWm / 100).toFixed(6) }; });
      capexItemsPlant = 'solar';
      var capexToggleEl = $('#capexDetailToggle');
      if (capexToggleEl) capexToggleEl.checked = true;
      toggleCapexDetail(true);
    }
    setVal('[data-k="decomEok"]', ref.results.철거비 / 100);
    setVal('[data-k="depRatio"]', 95); setVal('[data-k="depYears"]', 20);
    setVal('[data-k="lossRate"]', 80); setVal('[data-k="taxFlat"]', 21);
    setVal('[data-k="dsraMonths"]', 6); setVal('[data-k="minCash"]', 10);
    setVal('[data-k="divDSCR"]', 1.1); setVal('[data-k="divCumDSCR"]', 1.15);
    setVal('[data-k="divStartYear"]', 2); setVal('[data-k="discount"]', 5.5);
    syncEquityRatio(false); // 참고용 — 실제 계산은 presetInp를 그대로 씀, 이 필드는 표시만

    buildSpendCurve();
    ref.spendCurve_KRWm.forEach(function (v, i) {
      var e = $('[data-spend="' + i + '"]'); if (e) e.value = (v / 100).toFixed(2);
    });
    updateSpendSum();

    var byName = {};
    ref.tranches.forEach(function (t) { byName[t.name] = t; });
    TRANCHES.forEach(function (tr) {
      var t = byName[tr.name];
      if (!t) return;
      setVal('input[data-tr="' + tr.key + '"][data-f="amountEok"]', t.amount / 100);
      setVal('input[data-tr="' + tr.key + '"][data-f="order"]', t.order);
      setVal('input[data-tr="' + tr.key + '"][data-f="rateC"]', (t.rateCon * 100).toFixed(3));
      setVal('input[data-tr="' + tr.key + '"][data-f="rateO"]', (t.rateOp * 100).toFixed(3));
      setVal('input[data-tr="' + tr.key + '"][data-f="graceYears"]', t.graceYears);
      setVal('input[data-tr="' + tr.key + '"][data-f="repayYears"]', t.repayYears);
      var sel = $('select[data-tr="' + tr.key + '"]');
      if (sel && t.method === 3 && !sel.querySelector('option[value="3"]')) {
        sel.appendChild(new Option('64회차(당진 실측)', '3'));
      }
      if (sel) sel.value = String(t.method);
    });

    presetInp = buildDangjinInp(ref);
    usingPreset = true;
    suppressDirty = false;
    // 예시 값도 참고치 — 직접 입력으로 취급하지 않는다(설비용량을 바꾸면 함께 조정).
    if (typeof mwManual !== 'undefined') {
      Object.keys(mwManual).forEach(function (k) { mwManual[k] = false; });
      Object.keys(MW_RATE).forEach(mwStatus);
    }
    updateCodDisplay();
    toast('예시값(당진1, 100MW급 PJT)을 불러왔습니다 — 바로 "생성"을 눌러보시거나, 숫자를 고쳐가며 시나리오를 만들어보세요');
  }

  var model = null;
  var lastRunState = null;   // 마지막 생성에 쓰인 입력 상태(엑셀 '다시 열기' 링크용)
  var cachedShare = null;    // { json, url } — 입력이 그대로면 인쇄 머리말에 쓰는 압축 링크
  var f0 = function (n) { return Math.round(n).toLocaleString('ko-KR'); };
  var pct = function (n) { return n === null || n === undefined || isNaN(n) ? '—' : (n * 100).toFixed(2); };
  var fx = function (n) { return n === null || n === undefined || isNaN(n) ? '—' : n.toFixed(2); };
  var fyr = function (n) { return n === null || n === undefined || isNaN(n) ? '회수 안 됨' : n.toFixed(1); };
  var feok = function (n) { return Math.round(n / 100).toLocaleString('ko-KR'); }; // KRWm → 억원

  // 값 부호/구간에 따라 강조색을 입힌다 — 음수(적자)는 빨강, DSCR은
  // 임계값(1.0/1.2)에 따라 빨강/주황/초록, 회수 안 됨도 빨강.
  function kpiTone(raw, kind) {
    if (raw === null || raw === undefined || isNaN(raw)) return kind === 'payback' ? 'bad' : '';
    if (kind === 'dscr') return raw < 1.0 ? 'bad' : raw < 1.2 ? 'warn' : 'good';
    if (kind === 'neg') return raw < 0 ? 'bad' : '';
    return '';
  }

  function kpiGroup(title, items) {
    var wrap = el('div', 'grp');
    wrap.appendChild(el('b', null, title));
    var grid = el('div', 'kpis');
    items.forEach(function (it) {
      var d = el('div', 'kpi' + (it[4] ? ' ' + it[4] : ''));
      d.appendChild(el('div', 'k', it[0]));
      d.appendChild(el('div', 'v', it[1] + '<em>' + it[2] + '</em>'));
      if (it[3]) d.appendChild(el('div', 'n2', it[3]));
      grid.appendChild(d);
    });
    wrap.appendChild(grid);
    return wrap;
  }

  /* 조달 부족 안내 — 결과 자리에 띄우고 "조달 맞추고 다시 생성" 버튼을 준다. */
  function showFundingBlock(probe) {
    var short = probe.con.unfunded / 100;                                     // 억원
    var need = probe.con.needTotal / 100;
    var funded = probe.con.drawn.reduce(function (a, b) { return a + b; }, 0) / 100;
    var box = $('#kpis');
    box.innerHTML = '';
    var w = el('div', 'fundErr');
    w.appendChild(el('div', 'fundErrT', '조달이 ' + f0(short) + '억원 부족해서 생성하지 않았습니다'));
    w.appendChild(el('div', 'fundErrB',
      '조달해야 하는 돈(소요액)은 총사업비만이 아니라 DSRA 적립액과 건설이자까지 포함합니다. ' +
      '지금은 소요액 ' + f0(need) + '억원 중 ' + f0(funded) + '억원만 조달됩니다(자본금 + 트랜치 약정). ' +
      '이대로 계산하면 못 빌린 돈이 공짜로 들어온 셈이 되어 이자가 적게 잡히고 수익률이 실제보다 좋게 나옵니다.'));
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'btn'; btn.textContent = '조달 맞추고 다시 생성';
    btn.addEventListener('click', function () { autoSizeFunding(); run(); });
    w.appendChild(btn);
    w.appendChild(el('div', 'fundErrB', '직접 맞추시려면 트랜치 금액이나 자기자본을 ' + f0(short) + '억원만큼 늘리세요.'));
    box.appendChild(w);
    $('#xls').disabled = true;
    $('#metaNote').textContent = '';
    $('#shResults').innerHTML = '';
    toast('조달 부족 ' + f0(short) + '억원 — 생성을 멈췄습니다');
  }

  function renderKPIs() {
    var k = model.kpi;
    var capMW = model.inp.capacityMW;
    var capexPerMW = capMW > 0 ? model.tic / 100 / capMW : null;         // 억원/MW
    var opexPerMWyr = capMW > 0 ? (k.totalOpex / model.inp.operationYears) / capMW : null; // KRWm/MW/yr

    var box = $('#kpis'); box.innerHTML = '';

    /* 운영 중 현금 부족 경고. 조달 부족과 달리 "입력 모순"이 아니라 사업성 결과이므로
       계산은 보여주되, 이 상태에서 배당·FCFE IRR 이 과대평가된다는 걸 분명히 알린다
       (모델은 현금이 음수여도 배당만 0으로 막고 계산을 계속한다). */
    if (k.totalEquityInject > 1) {
      var cw = el('div', 'cashWarn');
      cw.appendChild(el('div', 'cashWarnT', '운영 중 자금이 부족해 추가 출자 ' + feok(k.totalEquityInject) + '억원이 들어갔습니다'));
      cw.appendChild(el('div', 'cashWarnB',
        '영업현금흐름이 원리금을 못 덮는 분기가 있어, 부족분을 주주 추가 출자로 메우는 것으로 계산했습니다' +
        '(현금 잔액은 음수가 될 수 없으므로 반드시 누군가 넣어야 하는 돈입니다). 아래 Equity IRR 에는 이 ' +
        '출자가 유출로 반영돼 있습니다 — 즉 처음 약정한 자기자본만으로는 사업이 돌아가지 않는 구조입니다. ' +
        '상환기간 연장·자기자본 확대·DSRA 기준 완화로 추가 출자가 0 이 되게 맞추는 것을 권합니다.'));
      box.appendChild(cw);
    }

    // 히어로 카드 — 사업자가 가장 먼저 보고 싶어할 "실수령 기준" 수익률
    var hero = el('div', 'kpiHero');
    hero.innerHTML = '<div class="hk">Equity IRR (배당)</div>' +
      '<div class="hv' + (k.dividendIRR !== null && k.dividendIRR < 0 ? ' bad' : '') + '">' + pct(k.dividendIRR) + '<em>%</em></div>' +
      '<div class="hsub">실제 배당 수령 기준 — 가장 보수적/현실적인 수익률 · 투자배수 ' + fx(k.equityMultiple) + '배 · 회수기간 ' + fyr(k.paybackYears) + (k.paybackYears === null ? '' : '년') + '</div>';
    box.appendChild(hero);

    // 세전은 세후보다 덜 중요한 참고값이라 왼쪽에 두고 톤을 흐리게(dim),
    // 세후는 오른쪽에 두고 원래 톤 그대로 — 같은 지표를 나란히 비교하기 쉽게.
    box.appendChild(kpiGroup('수익성 상세', [
      ['Equity IRR (FCFE) 세전', pct(k.equityIRRPre), '%', '', (kpiTone(k.equityIRRPre, 'neg') + ' dim').trim()],
      ['Equity IRR (FCFE) 세후', pct(k.equityIRR), '%', '원리금 갚고 남은 현금 전부가 출자자 몫이라고 볼 때(배당 제한 없음)', kpiTone(k.equityIRR, 'neg')],
      ['Project IRR 세전', pct(k.projectIRRPre), '%', '', (kpiTone(k.projectIRRPre, 'neg') + ' dim').trim()],
      ['Project IRR 세후', pct(k.projectIRR), '%', '실제 납부 법인세 기준(원본 FS 정의) — 이자 손금이 반영돼 있어 Equity 세후와 직접 비교하면 안 됩니다', kpiTone(k.projectIRR, 'neg')],
      ['Project IRR 세후(무차입 기준)', pct(k.projectIRRUnlev), '%', '차입이 전혀 없다고 보고 법인세를 다시 계산한 값 — 교과서·국제 자문사 정의. 레버리지 효과는 이 값과 Equity 세후를 비교하세요', (kpiTone(k.projectIRRUnlev, 'neg') + ' dim').trim()],
      ['Investor IRR', pct(k.investorIRR), '%', '출자자+대주단 합산 — 자본·대출 투입 vs 원리금·배당 회수', kpiTone(k.investorIRR, 'neg')]
    ]));
    box.appendChild(kpiGroup('사업 규모·수익구조', [
      ['연평균 EBITDA', f0(k.avgEbitda), 'KRWm/yr', '', kpiTone(k.avgEbitda, 'neg')],
      ['EBITDA 마진', k.ebitdaMargin === null ? '—' : (k.ebitdaMargin * 100).toFixed(1), '%'],
      ['NPV(프로젝트)', feok(k.npv), '억원', '', kpiTone(k.npv, 'neg')],
      ['LCOE(균등화발전단가)', k.lcoe ? k.lcoe.toFixed(1) : '—', '원/kWh', '판매단가와 같은 단위 — LCOE보다 판매단가가 높아야 수익이 남'],
      ['MW당 총투자비(TIC)', capexPerMW === null ? '—' : capexPerMW.toFixed(2), '억원/MW', '건설이자(IDC) 포함 총투자비 기준 — 위에 입력한 "총사업비"(건설이자 제외)와는 다른 값입니다'],
      ['MW당 연평균 운영비', opexPerMWyr === null ? '—' : f0(opexPerMWyr), 'KRWm/MW/yr']
    ]));
    box.appendChild(kpiGroup('리스크', [
      ['운전자금 추가 출자', k.totalEquityInject === undefined ? '—' : feok(k.totalEquityInject), '억원',
        '영업현금으로 원리금을 못 덮는 분기에 주주가 더 넣어야 하는 돈입니다(현금 잔액은 음수가 될 수 없음). 0 이 아니면 약정 자기자본만으로는 사업이 안 돌아가며, 위 Equity IRR 에는 이 출자가 반영돼 있습니다',
        k.totalEquityInject > 1 ? 'bad' : ''],
      ['운영 중 최저 보유현금', k.minCashClose === null ? '—' : feok(k.minCashClose), '억원',
        '추가 출자를 반영한 뒤의 최저 잔액이라 0 이상입니다', ''],
      ['최소 DSCR(연 합산)', k.minDSCRAnnual === null ? '—' : k.minDSCRAnnual.toFixed(3), 'x',
        '연도별 CFADS합/원리금합 중 최솟값 — 1.0 미만이면 그 해 상환재원이 부족했다는 뜻', kpiTone(k.minDSCRAnnual, 'dscr')]
    ]));

    $('#metaNote').textContent = '기간 수(분기): ' + model.periods.length +
      ' · 마지막 분기: ' + model.periods[model.periods.length - 1].endStr +
      ' · 총영업수익 ' + f0(k.totalRevenue) + 'KRWm · 총선순위이자 ' + f0(k.totalInterest) + 'KRWm' +
      ' · 총투자비(TIC) ' + f0(model.tic) + 'KRWm';

    var shBox = $('#shResults');
    shBox.innerHTML = '';
    if (k.shareholders && k.shareholders.length > 1) {
      var wrap = el('div', 'grp');
      wrap.appendChild(el('b', null, '사업자별 배분'));
      var t = el('table', 'tr');
      t.innerHTML = '<thead><tr><th>사업자</th><th>지분율</th><th>출자금액(KRWm)</th><th>누적배당(KRWm)</th></tr></thead>';
      var tb = document.createElement('tbody');
      k.shareholders.forEach(function (sh) {
        var row = document.createElement('tr');
        row.innerHTML = '<td>' + sh.name + '</td><td style="text-align:right">' + sh.stakePct.toFixed(2) +
          '%</td><td style="text-align:right">' + f0(sh.equityKRWm) + '</td><td style="text-align:right">' + f0(sh.dividendKRWm) + '</td>';
        tb.appendChild(row);
      });
      t.appendChild(tb);
      wrap.appendChild(t);
      shBox.appendChild(wrap);
    }
  }

  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('on');
    setTimeout(function () { t.classList.remove('on'); }, 2600);
  }

  function run() {
    // 예전엔 "생성"을 다시 누르면 민감도 결과를 지웠는데(기준값이
    // 달라질 수 있다는 이유였음), 순서를 안 지키면 다운로드에서
    // 민감도가 빠져버려 헷갈린다는 피드백으로 제거 — 이제 민감도는
    // "민감도 분석 실행"을 다시 누르기 전까지 그대로 유지되고, 생성을
    // 몇 번을 다시 눌러도 Excel 다운로드에 그대로 딸려간다.
    var inp;
    if (usingPreset && presetInp) {
      inp = presetInp;
    } else {
      var core = readCore();
      var tranches = readTranches();
      var spendCurve = readSpendCurve();
      inp = Object.assign({}, core, {
        ppy: 4,
        spendCurve: spendCurve,
        equityOrder: 1,
        tranches: tranches.map(function (t) {
          return {
            name: t.name, amountEok: t.amountEok, order: t.order,
            rateC: t.rateC, rateO: t.rateO, graceYears: t.graceYears, repayYears: t.repayYears,
            method: t.method
          };
        }),
        // 1 = 한국 법인세 누진 브래킷, 그 외 = taxFlat 단일세율.
        // "단일세율 사용" 토글이 꺼져 있으면 누진이 기본이다.
        taxMode: taxFlatOn ? 2 : 1,
        localSurtaxRate: 10   // 한국 지방소득세(법인세의 10%)는 기본 적용
      });
      inp.tariffTracks = buildTariffTracks(core);
      applyPlantGen(inp);
      // 운영비 항목별 입력을 켰으면 엔진이 이미 지원하는 opexItems 경로로
      // 넘겨서 계산 자체가 항목별 상승률·선순위/후순위를 반영하게 한다
      // (안 켰으면 기존처럼 총액 근사).
      if (opexDetailOn) {
        inp.opexItems = readOpexItemsDetailed().map(function (it) {
          return { name: it.name, annualKRWm: (it.amountEok || 0) * 100, escal: it.escal, senior: it.senior };
        });
      }
    }
    // 사업자 구성은 프리셋 여부와 무관하게 화면 입력을 그대로 쓴다 —
    // 자본금 총액을 나눠 낸 여러 출자자에게 지분율만큼 배당을 배분하는
    // 표시용 계산이라 원본 검증치(periodOverrides 등)와는 독립적이다.
    inp = Object.assign({}, inp, { shareholders: readShareholders() });
    try {
      var probe = M.computeModel(inp);
      /* 조달 부족(약정 < 소요액)이면 결과를 내지 않는다.
         이 상태로 계산하면 못 빌린 돈이 공짜로 조달된 셈이 되어 이자·원리금이
         과소계상되고 IRR이 과대평가된다 — 경고만 띄우면 그대로 보고까지 흘러가므로
         아예 막고, 한 번에 맞추는 버튼을 준다 (2026-10-02). */
      if (probe.con && probe.con.unfunded > 1) {
        showFundingBlock(probe);
        return;
      }
      model = probe;
      // 엑셀에 넣는 '다시 열기' 링크는 지금 화면이 아니라 이 결과를 만든 입력을 가리켜야 한다
      // (생성 뒤 입력을 고치고 다운로드하는 경우). 생성 시점의 상태를 잡아 둔다.
      try { lastRunState = snapshotState(); } catch (e) { lastRunState = null; }
      // Ctrl+P(beforeprint)는 비동기 압축을 기다릴 수 없어서, 생성할 때 압축 링크를 미리 만들어 둔다.
      if (lastRunState) {
        var stJson = JSON.stringify(lastRunState);
        Promise.resolve().then(function () { return encodeState(lastRunState); })
          .then(function (code) { cachedShare = { json: stJson, url: shareUrlOf(code) }; })
          .catch(function () { /* 인쇄 때 비압축 링크로 대체 */ });
      }
      // 총사업비/운영비 세부 항목은 계산 결과가 아니라 엑셀 표시용
      // 부가정보 — 합계만 입력한 경우에도 엑셀에는 항목 이름이 나오고
      // 금액만 비워두고 싶다는 요청 반영. capexItems는 항상 붙이고
      // (엔진이 쓰는 값이 아니라 순수 표시용), opexDisplayItems는
      // inp.opexItems(실제 계산에 쓰인 항목별 값)가 없을 때만 붙인다 —
      // 있으면 xlsxbuild2.js가 그 실제값으로 이미 항목별 표시를 한다.
      model.capexItems = capexDetailOn ? readCapexItems() : defaultCapexItemsFor(plantType).map(function (n) { return { name: n, amountEok: null }; });
      if (!inp.opexItems) {
        model.opexDisplayItems = defaultOpexItemsFor(plantType).map(function (d) { return { name: d.name, amountEok: null }; });
      }
      renderKPIs();
      $('#xls').disabled = false;
      // 거치+상환기간이 공사기간보다 짧으면 공사 중에 상환이 끝나 버린다(이후 인출분은
      // 갚을 회차가 없음). 계산은 되지만 현실적인 조건이 아니고 화면·엑셀 결과도
      // 달라질 수 있으니 알려 준다.
      var firstOp = -1;
      model.periods.forEach(function (p, i) { if (p.isOp && firstOp < 0) firstOp = i; });
      var earlyEnd = (model.tranches || []).filter(function (t) {
        return t.nRepay > 0 && firstOp >= 0 && t.repayEndIdx < firstOp;
      }).map(function (t) { return t.name; });
      if (earlyEnd.length) {
        toast('주의: ' + earlyEnd.join('·') + ' 상환이 준공 전에 끝납니다 — 거치·상환기간을 확인하세요 (이 조건에선 엑셀 결과가 화면과 다를 수 있음)');
      } else {
        toast(usingPreset ? '당진 FS 실측치 기준으로 생성 완료 (원본과 검증된 값)' : '재무모델 생성 완료');
      }
    } catch (e) {
      toast('생성 실패: ' + e.message);
      console.error(e);
    }
  }

  function download() {
    if (!model) return;
    if (lastSensResults) model.sensitivity = lastSensResults;
    var btn = $('#xls'); btn.disabled = true; btn.textContent = '생성 중…';
    var st = lastRunState || snapshotState();
    // 링크는 부가 정보 — 만들다 실패해도(동기 예외 포함) 엑셀 다운로드는 그대로 진행한다.
    Promise.resolve().then(function () { return encodeState(st); }).then(shareUrlOf)
      .catch(function () { return null; }).then(function (url) {
      model.shareUrl = url;
      return X.buildWorkbook(model, window.ExcelJS).xlsx.writeBuffer();
    }).then(function (buf) {
      var blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = (model.inp.projectName || '재무모델') + '_v2.xlsx';
      document.body.appendChild(a); a.click(); a.remove();
      btn.disabled = false; btn.textContent = 'Excel 다운로드';
      toast('Excel 다운로드 완료');
    }).catch(function (e) {
      btn.disabled = false; btn.textContent = 'Excel 다운로드';
      toast('다운로드 실패: ' + e.message);
      console.error(e);
    });
  }

  // 예시 불러오기 버튼을 다시 전체 공개로 되돌리면서(빠른 시작용으로
  // 재해석), 민감도 카드의 "프리셋 상태에선 의미 없음" 안내도 같이
  // 보이게 한다 — 이제 누구나 누를 수 있는 버튼이라 그 주의사항도
  // 다시 필요함.
  var sensHint = $('#adminSensHint'); if (sensHint) sensHint.style.display = 'inline';

  buildCore();
  (function () {
    var h = $('#plantHint'); if (h) h.innerHTML = plantCmpHtml(plantType);
    bindPlantCmp();
    document.querySelectorAll('[data-plant-btn]').forEach(function (b) {
      b.addEventListener('click', function () { setPlantType(b.getAttribute('data-plant-btn')); });
    });
  })();
  buildTrancheGrid();
  buildShareholderGrid();
  buildSpendCurve();
  updateRecWeightState();
  updateCodDisplay();
  $('#trQuick').addEventListener('click', quickFillTranches);

  /* 조달 자동 맞춤 연동.
     · 트랜치 금액을 사람이 직접 고치면 그 값을 존중하고 자동 산정을 끈다.
     · 자동 산정 상태에서 소요액에 영향 주는 입력(총사업비·DSRA·공사기간·지출곡선·
       건설금리)이 바뀌면 부채를 다시 맞춘다 — 안 그러면 총사업비만 올리고
       부채는 그대로여서 조달이 부족해진다. */
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (!t || !t.matches) return;
    if (t.matches('input[data-tr][data-f="amountEok"]') && !suppressDirty) { debtAutoSized = false; return; }
    if (!debtAutoSized || suppressDirty) return;
    var k = t.getAttribute('data-k');
    var affects = k === 'capexEok' || k === 'dsraEok' || k === 'constructionMonths' ||
      k === 'constructionStart' || k === 'equityEok' || k === 'equityRatioPct';
    var isRate = t.matches('input[data-tr][data-f="rateC"]');
    var isSpend = t.matches('[data-spend]');
    if (!affects && !isRate && !isSpend) return;
    clearTimeout(reFundTimer);
    reFundTimer = setTimeout(function () { if (debtAutoSized) autoSizeFunding({ silent: true }); }, 120);
  });
  var reFundTimer = null;

  // 어떤 입력이든 바뀌면 민감도 결과의 유효성을 다시 본다(지문 비교라 값이 같으면 유지)
  ['input', 'change'].forEach(function (evt) {
    document.addEventListener(evt, function (e) {
      if (suppressDirty) return;
      var t = e.target;
      if (!t || !t.matches) return;
      if (t.matches('[data-sens-f]')) return;          // 민감도 표 자체 편집은 제외
      if (t.matches('[data-k],[data-tr],[data-spend],[data-capex-f],[data-opex-f],[data-sh-name],[data-sh-stake],input[type="checkbox"],select')) {
        clearTimeout(staleTimer);
        staleTimer = setTimeout(invalidateSensIfInputChanged, 150);
      }
    });
  });
  var staleTimer = null;
  $('[data-k="rpsShare"]').addEventListener('input', updateRecWeightState);
  $('[data-k="constructionStart"]').addEventListener('input', updateCodDisplay);
  $('[data-k="constructionMonths"]').addEventListener('input', updateCodDisplay);
  $('[data-k="constructionMonths"]').addEventListener('change', buildSpendCurve);
  $('[data-k="capexEok"]').addEventListener('change', buildSpendCurve);
  $('[data-k="capexEok"]').addEventListener('input', function () { if ($('[data-k="equityRatioPct"]').value !== '') syncEquityRatio(true); });
  $('[data-k="equityEok"]').addEventListener('input', function () { syncEquityRatio(false); });
  $('[data-k="equityRatioPct"]').addEventListener('input', function () { syncEquityRatio(true); });
  $('#spendReset').addEventListener('click', buildSpendCurve);
  $('#spendbox').addEventListener('input', updateSpendSum);
  $('#capexDetailToggle').addEventListener('change', function (e) { toggleCapexDetail(e.target.checked); });
  $('#capexItemBox').addEventListener('input', updateCapexItemSum);
  $('#opexDetailToggle').addEventListener('change', function (e) { toggleOpexDetail(e.target.checked); });
  $('#opexItemBox').addEventListener('input', updateOpexItemSum);
  // 단일세율 토글 — 껐을 때 세율칸이 아무 효과 없는 채로 남아 오해를 주지 않도록
  // 입력 가능 여부를 함께 바꾼다.
  (function () {
    var cb = $('#taxFlatToggle'), fld = $('[data-k="taxFlat"]');
    function sync() {
      taxFlatOn = !!(cb && cb.checked);
      if (fld) {
        fld.disabled = !taxFlatOn;
        fld.style.opacity = taxFlatOn ? '' : '.5';
        fld.title = taxFlatOn ? '' : '누진 브래킷 사용 중 — 이 값은 계산에 쓰이지 않습니다';
      }
    }
    if (cb) cb.addEventListener('change', sync);
    sync();
  })();
  $('[data-k="capacityMW"]').addEventListener('input', updateOpexMWRefs);

  /* 규모에 비례해야 하는 금액 — 최초 DSRA · 철거복구비 · 최소보유현금.
     예전에는 100MW 기준 억원 금액(50/20/10)이 기본값으로 고정돼 있어서,
     설비용량을 10MW로 바꿔도 그대로 남았다. 10MW에 DSRA 50억이 들어가면
     그만큼 건설기간에 더 빌렸다가 준공 때 돌려주는 식이 돼서 Equity IRR이
     16%대가 아니라 -52%로 나올 만큼 왜곡된다.
       - 기본은 "설비용량 × MW당 단가"로 자동 계산하고 설비용량을 따라간다.
       - 사용자가 칸에 직접 입력하면 그 값이 우선이고, 이후엔 따라가지 않는다
         (칸을 비우면 다시 자동으로 돌아간다).
       - "예시 불러오기"로 채운 값도 참고치일 뿐이라 자동 상태로 취급한다
         — 설비용량을 바꾸면 함께 조정된다. (프리셋은 이벤트 없이 값을
         넣으므로 여기서 '직접 입력'으로 잡히지 않는다.) */
  var MW_RATE = { dsraEok: 0.5, decomEok: 0.2, minCash: 0.1 };   // 억원/MW
  var mwManual = {};
  function capMW() { return Number(($('[data-k="capacityMW"]') || {}).value) || 0; }
  function mwStatus(k) {
    var e = $('[data-k="' + k + '"]');
    var tag = document.querySelector('[data-mw-status="' + k + '"]');
    if (!e || !tag) return;
    var cap = capMW(), v = Number(e.value);
    var per = cap > 0 && e.value !== '' ? (v / cap) : null;
    tag.textContent = (per === null ? 'MW당 —' : ('현재 MW당 ' + per.toFixed(2) + '억')) +
      (mwManual[k] ? ' · 직접 입력값 사용 중 (칸을 비우면 자동으로 돌아갑니다)'
                   : ' · 자동 (설비용량 × ' + MW_RATE[k] + '억/MW)');
    tag.className = 'mwstat' + (mwManual[k] ? ' manual' : '');
  }
  function applyMwScaled() {
    var cap = capMW();
    Object.keys(MW_RATE).forEach(function (k) {
      var e = $('[data-k="' + k + '"]');
      if (!e) return;
      if (!mwManual[k] && cap > 0) e.value = +(MW_RATE[k] * cap).toFixed(2);
      mwStatus(k);
    });
  }
  Object.keys(MW_RATE).forEach(function (k) {
    var e = $('[data-k="' + k + '"]');
    if (!e) return;
    // 설명 아래에 "지금 MW당 얼마인지 / 자동인지 직접 입력인지"를 표시한다.
    var box = e.closest ? e.closest('.f') : null;
    if (box) {
      var tag = document.createElement('div');
      tag.setAttribute('data-mw-status', k);
      tag.className = 'mwstat';
      box.appendChild(tag);
    }
    e.addEventListener('input', function () { mwManual[k] = e.value !== ''; mwStatus(k); });
    e.addEventListener('change', function () {
      if (e.value === '') { mwManual[k] = false; applyMwScaled(); }
    });
  });
  $('[data-k="capacityMW"]').addEventListener('input', applyMwScaled);
  $('[data-k="capacityMW"]').addEventListener('change', applyMwScaled);
  applyMwScaled();
  $('#shAdd').addEventListener('click', function () {
    SHAREHOLDERS.push({ name: '출자자' + (SHAREHOLDERS.length + 1), stakePct: 0 });
    buildShareholderGrid();
  });
  $('#shbox').addEventListener('input', updateShareholderSum);
  buildSensGrid();
  $('#sensAdd').addEventListener('click', function () {
    SENS_ROWS.push({ name: 'Case' + SENS_ROWS.length, tariffAbs: null, capexAbs: null, opexAbs: null, rateAbs: null });
    buildSensGrid();
  });
  $('#sensRun').addEventListener('click', runSensitivity);
  $('#run').addEventListener('click', run);
  $('#xls').addEventListener('click', download);
  $('#loadDangjin').addEventListener('click', loadDangjin);

  // 프리셋 로드 후 사용자가 아무 값이나 직접 고치면 더는 "검증된 원본값"이
  // 아니므로 usingPreset을 해제한다(다시 폼을 읽어서 계산하는 일반 경로로).
  // 이때 "64회차(당진 실측)" 방식으로 남아있던 select는 일반 경로에서
  // schedule 데이터가 없어 원금이 영원히 0으로 계산돼 결과가 깨지므로
  // 방식 1(원금균등)로 되돌려준다.
  function dropUnsupportedMethod3() {
    document.querySelectorAll('select[data-tr]').forEach(function (sel) {
      if (sel.value === '3') sel.value = '1';
    });
  }
  document.addEventListener('input', function (e) {
    if (suppressDirty || !usingPreset) return;
    if (e.target.matches('[data-k],[data-tr],[data-spend]')) { usingPreset = false; dropUnsupportedMethod3(); }
  });
  document.addEventListener('change', function (e) {
    if (suppressDirty || !usingPreset) return;
    if (e.target.matches('[data-k],[data-tr],[data-spend]')) { usingPreset = false; dropUnsupportedMethod3(); }
  });

  /* =========================================================
     입력값 공유 링크 · PDF 저장
     - 화면의 입력 상태 전체(기본 필드·발전원·토글·총사업비/운영비 항목·트랜치·
       지출 스케줄·출자자·민감도 행·MW 비례 직접입력 여부)를 JSON 으로 모아
       압축한 뒤 링크의 '#s=' 뒤에 붙인다. '#' 뒤는 서버로 전송되지 않고
       브라우저 안에서만 읽힌다 — 대신 링크를 가진 사람은 누구나 값을 본다.
     - 예시(당진)를 그대로 쓰는 상태면 80분기 실측치를 담는 대신 "예시"라는
       표시만 저장하고, 열 때 예시 불러오기를 다시 실행한다.
     - 복원 순서가 중요하다: 총사업비 'change' 가 지출 스케줄을 기본값으로
       다시 만들기 때문에 스케줄은 맨 마지막에 채운다.
     ========================================================= */
  var SHARE_VER = 1;

  function snapshotState() {
    var s = { v: SHARE_VER, plant: plantType };
    s.sh = readShareholders().map(function (x) { return [x.name, x.stakePct]; });
    s.sens = readSensRows().map(function (r) { return [r.name, r.tariffAbs, r.capexAbs, r.opexAbs, r.rateAbs]; });
    if (usingPreset) { s.preset = 1; return s; }
    var core = {};
    document.querySelectorAll('input[data-k],select[data-k]').forEach(function (e) { core[e.dataset.k] = e.value; });
    s.core = core;
    s.mw = Object.keys(mwManual).filter(function (k) { return mwManual[k]; });
    s.tf = taxFlatOn ? 1 : 0;
    s.cx = capexDetailOn ? 1 : 0;
    s.cxp = capexItemsPlant;
    s.cxi = (capexDetailOn ? readCapexItems() : CAPEX_ITEMS).map(function (x) { return [x.name, x.amountEok]; });
    s.ox = opexDetailOn ? 1 : 0;
    s.oxp = opexItemsPlant;
    s.oxi = (opexDetailOn ? readOpexItemsDetailed() : OPEX_ITEMS).map(function (x) {
      return [x.name, x.amountEok, x.escal, x.senior ? 1 : 0];
    });
    s.tr = TRANCHES.map(function (tr) {
      var g = function (f) { var e = $('input[data-tr="' + tr.key + '"][data-f="' + f + '"]'); return e ? e.value : ''; };
      var sel = $('select[data-tr="' + tr.key + '"]');
      return [tr.key, tr.name, g('amountEok'), g('order'), g('rateC'), g('rateO'), g('graceYears'), g('repayYears'), sel ? sel.value : '1'];
    });
    s.sp = Array.prototype.slice.call(document.querySelectorAll('[data-spend]')).map(function (e) { return e.value; });
    return s;
  }

  function restoreState(s) {
    if (!s || s.v !== SHARE_VER) throw new Error('지원하지 않는 링크 형식입니다');
    if (s.preset) {
      loadDangjin();
    } else {
      suppressDirty = true;
      try {
        if (s.plant && s.plant !== plantType) setPlantType(s.plant);
        Object.keys(s.core || {}).forEach(function (k) {
          var e = $('[data-k="' + k + '"]'); if (e) e.value = s.core[k];
        });
        var tfb = $('#taxFlatToggle');
        if (tfb) { tfb.checked = !!s.tf; tfb.dispatchEvent(new Event('change', { bubbles: true })); }

        CAPEX_ITEMS = (s.cxi || []).map(function (a) { return { name: a[0], amountEok: a[1] }; });
        capexItemsPlant = s.cxp || plantType;
        var cxb = $('#capexDetailToggle');
        if (cxb) cxb.checked = !!s.cx;
        if (s.cx) toggleCapexDetail(true);

        OPEX_ITEMS = (s.oxi || []).map(function (a) { return { name: a[0], amountEok: a[1], escal: a[2], senior: !!a[3] }; });
        opexItemsPlant = s.oxp || plantType;
        var oxb = $('#opexDetailToggle');
        if (oxb) oxb.checked = !!s.ox;
        if (s.ox) toggleOpexDetail(true);

        TRANCHES = (s.tr || []).map(function (a) {
          return { key: a[0], name: a[1], amountEok: Number(a[2]), order: Number(a[3]), rateC: Number(a[4]),
            rateO: Number(a[5]), graceYears: Number(a[6]), repayYears: Number(a[7]), method: Number(a[8]) };
        });
        buildTrancheGrid();
        (s.tr || []).forEach(function (a) {
          ['amountEok', 'order', 'rateC', 'rateO', 'graceYears', 'repayYears'].forEach(function (f, i) {
            var e = $('input[data-tr="' + a[0] + '"][data-f="' + f + '"]'); if (e) e.value = a[2 + i];
          });
          var sel = $('select[data-tr="' + a[0] + '"]'); if (sel) sel.value = a[8];
        });

        // 지출 스케줄은 맨 마지막 — 공사기간에 맞는 칸 수로 다시 만든 뒤 값을 채운다.
        buildSpendCurve();
        (s.sp || []).forEach(function (v, i) { var e = $('[data-spend="' + i + '"]'); if (e) e.value = v; });
        updateSpendSum();

        Object.keys(mwManual).forEach(function (k) { mwManual[k] = false; });
        (s.mw || []).forEach(function (k) { mwManual[k] = true; });
        Object.keys(MW_RATE).forEach(mwStatus);
        updateCodDisplay();
        updateOpexMWRefs();
      } finally {
        suppressDirty = false;
      }
    }
    SHAREHOLDERS = (s.sh || []).map(function (a) { return { name: a[0], stakePct: Number(a[1]) }; });
    buildShareholderGrid();
    SENS_ROWS = (s.sens || []).map(function (a) {
      return { name: a[0], tariffAbs: a[1], capexAbs: a[2], opexAbs: a[3], rateAbs: a[4] };
    });
    buildSensGrid();
  }

  // UTF-8 변환 — TextEncoder 가 없는 환경(구형 브라우저·테스트 환경)에서도 동작하게.
  function utf8Bytes(str) {
    if (typeof TextEncoder === 'function') return new TextEncoder().encode(str);
    var bin = unescape(encodeURIComponent(str)), u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function utf8Str(bytes) {
    if (typeof TextDecoder === 'function') return new TextDecoder().decode(bytes);
    var bin = '';
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return decodeURIComponent(escape(bin));
  }
  function b64url(bytes) {
    var bin = '';
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function unb64url(str) {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    var bin = atob(str), u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  // 'z' = 압축(deflate), 'j' = 압축 없음(압축을 못 하는 환경용). 여는 쪽은 둘 다 읽는다.
  function encodeState(s) {
    var bytes = utf8Bytes(JSON.stringify(s));
    if (typeof CompressionStream === 'function' && typeof Response === 'function') {
      try {
        return new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate')))
          .arrayBuffer().then(function (buf) { return 'z' + b64url(new Uint8Array(buf)); })
          .catch(function () { return 'j' + b64url(bytes); });
      } catch (e) { /* 아래 비압축으로 */ }
    }
    return Promise.resolve('j' + b64url(bytes));
  }
  function decodeState(code) {
    var kind = code.charAt(0), bytes;
    try { bytes = unb64url(code.slice(1)); } catch (e) { return Promise.reject(new Error('링크가 잘렸거나 손상됐습니다')); }
    if (kind === 'j') { try { return Promise.resolve(JSON.parse(utf8Str(bytes))); } catch (e) { return Promise.reject(new Error('링크가 손상됐습니다')); } }
    if (kind === 'z') {
      if (typeof DecompressionStream !== 'function') {
        return Promise.reject(new Error('이 브라우저는 압축된 링크를 열 수 없습니다(Chrome·Edge 최신 버전 권장)'));
      }
      return new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'))).text()
        .then(function (t) { return JSON.parse(t); });
    }
    return Promise.reject(new Error('알 수 없는 링크 형식입니다'));
  }
  // 공유 링크의 바탕 주소 — 이전 PDF 링크로 열었을 때 붙은 '?r=…' 같은 쿼리는 떼고 쓴다.
  function shareBase() { return location.href.split('#')[0].split('?')[0]; }
  function shareUrlOf(code) { return shareBase() + '#s=' + code; }
  function currentShareUrl() { return encodeState(snapshotState()).then(shareUrlOf); }

  function showShareBox(url, copied) {
    var box = $('#shareBox'); if (!box) return;
    box.innerHTML = '';
    var p = el('div', 'shareMsg', copied
      ? '입력값이 담긴 링크를 복사했습니다. 이 링크를 열면 지금 입력 상태가 그대로 복원됩니다.'
      : '아래 링크를 복사해 두세요. 이 링크를 열면 지금 입력 상태가 그대로 복원됩니다.');
    var ta = document.createElement('textarea');
    ta.readOnly = true; ta.value = url; ta.rows = 3; ta.className = 'shareUrl';
    ta.addEventListener('focus', function () { ta.select(); });
    var warn = el('div', 'shareWarn', '※ 링크를 가진 사람은 누구나 입력값을 볼 수 있습니다. 값은 링크 안에만 있고 서버에 저장되지 않습니다.');
    box.appendChild(p); box.appendChild(ta); box.appendChild(warn);
  }
  function copyShareLink() {
    currentShareUrl().then(function (url) {
      try { history.replaceState(null, '', '#s=' + url.split('#s=')[1]); } catch (e) { /* file:// 등 */ }
      var ok = function () { showShareBox(url, true); toast('입력값 링크를 복사했습니다'); };
      var fail = function () { showShareBox(url, false); toast('자동 복사가 막혀 있어 아래 링크를 직접 복사해 주세요'); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(ok, fail);
      else fail();
    }).catch(function (e) { toast('링크를 만들지 못했습니다: ' + e.message); });
  }

  // 인쇄(PDF) 머리말 — 사업명·작성일시·"이 입력으로 다시 열기" 링크.
  function fillPrintHead(url) {
    var name = (($('[data-k="projectName"]') || {}).value || '재무모델').trim();
    var now = new Date();
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var stamp = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) + ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes());
    var head = $('#printHead'); if (!head) return stamp;
    head.innerHTML = '';
    head.appendChild(el('div', 'ph1', name + ' — 입력값 · 결과 기록'));
    head.appendChild(el('div', 'ph2', '작성 ' + stamp + ' · ' + PLANT_LABEL[plantType] + (usingPreset ? ' · 당진 FS 예시값' : '') +
      (model ? '' : ' · 결과 없음(생성 전)')));
    // 지금 페이지 자신을 가리키는 링크(페이지#s=…)는 크롬이 PDF 에서 '문서 안 이동'으로 보고
    // 빼 버린다 — 쿼리를 하나 붙여 다른 주소로 만들면 PDF 에서도 클릭 링크로 남는다.
    var href = url.indexOf('#s=') >= 0
      ? url.split('#')[0] + '?r=' + Date.now().toString(36) + '#' + url.split('#')[1]
      : url;
    var a = document.createElement('a'); a.href = href; a.className = 'plink'; a.textContent = href;
    var lk = el('div', 'ph3', '이 입력으로 다시 열기: '); lk.appendChild(a);
    head.appendChild(lk);
    return stamp;
  }
  // 접힌 상세 항목은 인쇄하는 동안만 펼친다. 버튼이든 Ctrl+P 든 같은 처리.
  var printOpened = [], printTitle = null, printHeadReady = false;
  function preparePrint() {
    printOpened = [];
    document.querySelectorAll('details').forEach(function (d) { if (!d.open) { d.open = true; printOpened.push(d); } });
  }
  function finishPrint() {
    printOpened.forEach(function (d) { d.open = false; });
    printOpened = [];
    if (printTitle !== null) { document.title = printTitle; printTitle = null; }
    printHeadReady = false;
  }
  window.addEventListener('beforeprint', function () {
    // Ctrl+P 로 바로 인쇄한 경우: 압축은 비동기라 여기선 비압축 링크로 즉시 채운다.
    if (!printHeadReady) {
      var url = null, cur = null;
      try { cur = JSON.stringify(snapshotState()); } catch (e) { cur = null; }
      if (cur && cachedShare && cachedShare.json === cur) url = cachedShare.url;       // 압축 링크(짧음)
      else if (cur) url = shareUrlOf('j' + b64url(utf8Bytes(cur)));                  // 입력이 바뀌었으면 비압축
      fillPrintHead(url || location.href.split('#')[0]);
    }
    preparePrint();
  });
  window.addEventListener('afterprint', finishPrint);

  function savePdf() {
    // PDF 에는 지금 입력으로 다시 계산한 결과를 함께 싣는다.
    try { run(); } catch (e) { /* 결과 없이도 입력값은 인쇄 */ }
    currentShareUrl().then(function (url) {
      var stamp = fillPrintHead(url);
      printHeadReady = true;
      var name = (($('[data-k="projectName"]') || {}).value || '재무모델').trim();
      printTitle = document.title;
      document.title = name + '_입력값_' + stamp.slice(0, 10);   // 크롬·엣지는 이 제목을 PDF 파일 이름으로 쓴다
      setTimeout(function () { window.print(); }, 60);
    });
  }

  var shareBtn = $('#shareLink'); if (shareBtn) shareBtn.addEventListener('click', copyShareLink);
  var pdfBtn = $('#savePdf'); if (pdfBtn) pdfBtn.addEventListener('click', savePdf);

  // 공유 링크로 열었으면 입력 상태를 복원하고 바로 결과까지 계산한다.
  (function restoreFromHash() {
    var m = /^#s=([A-Za-z0-9_\-]+)$/.exec(location.hash || '');
    if (!m) return;
    decodeState(m[1]).then(function (s) {
      restoreState(s);
      try { run(); } catch (e) { /* 결과 계산 실패해도 입력 복원은 유지 */ }
      toast('링크에 담긴 입력값을 불러왔습니다');
    }).catch(function (e) { toast('링크를 불러오지 못했습니다: ' + e.message); });
  })();

  // 테스트·자동화용(화면 동작에는 영향 없음)
  window.SolarShare = { snapshot: snapshotState, restore: restoreState, encode: encodeState, decode: decodeState, url: currentShareUrl };
})();
